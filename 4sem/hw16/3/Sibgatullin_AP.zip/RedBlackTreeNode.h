#ifndef RedBlackTreeNODE_H
#define RedBlackTreeNODE_H

#include "record.h"
#include "hash.h"
#include "RedBlackTreeName.h"

class RedBlackTree;

class RedBlackTreeNode
{
    private:
        RedBlackTreeNode * LeftChild = nullptr;
	RedBlackTreeNode * RightChild = nullptr;
	RedBlackTreeNode * Parent = nullptr;
	Hash * phoneSearch = nullptr;
	RedBlackTreeName * nameSearch = nullptr;
	color Color = RED;

    public:
	friend class RedBlackTree;
	RedBlackTreeNode(int HashSize)
	{
	    nameSearch = new RedBlackTreeName;
	    phoneSearch = new Hash(HashSize);
	}

	~RedBlackTreeNode()
	{
	    delete nameSearch;
	    delete phoneSearch;
	}


	void print()
	{
	    if(nameSearch != nullptr && phoneSearch != nullptr)
	    {
		nameSearch->print(nameSearch->getRoot());
		phoneSearch->print();
	    }
	}

	int operator> (const ListNode &x)
	{
	    return nameSearch->getRoot()->Data->getGroup() > x.getGroup();
	}

	int operator< (const ListNode &x)
	{
	    return nameSearch->getRoot()->Data->getGroup() < x.getGroup();
	}

	int operator== (const ListNode &x)
	{
	    return nameSearch->getRoot()->Data->getGroup() == x.getGroup();
	}
};

#endif // RedBlackTreeNODE_H


