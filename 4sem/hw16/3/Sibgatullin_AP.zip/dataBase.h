#ifndef DATABASE_H
#define DATABASE_H

#include "list.h"
#include "RedBlackTree.h"


class DataBase
{
    List * Container = nullptr;
    RedBlackTree * GroupSearch = nullptr;
    public:
        DataBase(int HashSize)
	{
	    GroupSearch = new RedBlackTree(HashSize);
	    Container = new List;
	}
	DataBase() = default;
	~DataBase()
	{
	    delete GroupSearch;
	    delete Container;
	}

	int read(FILE * inFile);
	void print(FILE * outFile = stdout);
	void deleteDataBase();

	int insertingRequest(char* name, int phone, int group);
	int selectingRequest(Command & current);
	bool deletingRequest(Command & current);

	int requestExecute(Command & current, FILE * outputResult );
	void run(FILE * inputRequest = stdin, FILE *outputResult = stdout);
};

#endif // DATABASE_H
