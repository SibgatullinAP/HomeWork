#include "constants.h"

double f_1 (double x);
double f_2 (double x);
double f_3 (double x);
double f_4 (double x);
double f_5 (double x);

double d_1 (double x);
double d_2 (double x);
double d_3 (double x);
double d_4 (double x);
double d_5 (double x);

double anti_d_1 (double x);
double anti_d_2 (double x);
double anti_d_3 (double x);
double anti_d_4 (double x);
double anti_d_5 (double x);
