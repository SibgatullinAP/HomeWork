#include "task.h"

void process_function (int my_rank, const char * path);
