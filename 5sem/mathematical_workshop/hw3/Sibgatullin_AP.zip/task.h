#ifndef TASK
#define TASK

int min_finder (const char *file_name, double *min);
int counter (const char *file_name, double min);

#endif
