#ifndef COMMON_H
#define COMMON_H

#include<math.h>
#include <optional>
#include <algorithm>
//#include <numbers>
#include <string>
#include <vector>
//#include <ranges>
#include <stdio.h>
#include <math.h>
#include <stdarg.h>

#define MAX_STR_BUFF 100

#endif // COMMON_H
