#include <stdio.h>
#include "L.h"

void Q_Print_S (QMatrix_L *A)
{
  int dim = Q_GetDim (A);
  printf ("N = %d\n\n", dim);

  for (int i = 1; i <= dim; i++)
    {
      for (int j = 1; j <= dim; j++)
        {
          double el = Q_GetEl (A, i, j);
          if (LASResult() == LASOK && fabs (el) > 1e-16)
            {
              printf ("%d %d) %f \n", i, j, el);
            }
          else
            LASError (LASOK, "Q_GetEl", Q_GetName (A), NULL, NULL);
        }
      printf ("\n");
    }
}

void V_Print (Vector *x)
{
  int dim = V_GetDim (x);
  printf ("V dim = %d\n\n", dim);

  for (int i = 1; i <= dim; i++)
    {
      printf ("%d) %f \n", i, V_GetCmp (x, i));
    }
}
