#ifndef L_H
#define L_H

#include "laspack/qmatrix.h"
#include "laspack/errhandl.h"

void Q_Print_S (QMatrix_L *A);
void V_Print (Vector *x);

#endif // L_H
