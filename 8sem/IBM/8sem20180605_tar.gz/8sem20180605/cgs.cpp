#include <stdio.h>
#include <math.h>
#include "cgs.h"
#include "my_arrays.h"

#define ITMAX   2000
#define ITPREC  1.e-8
#define OMEGA 1

void set_e1 (double *x, int n)
{
  //x[0] = 1;
  double sq = 1 / sqrt (n);
  for (int i = 0; i < n; i++)
    x[i] = sq;
}

// Preonditioner Jacobi
int solve_linear_system_cgs (
    double *A, const int *I, // sparse matrix
    unsigned int n,                // order of system
    const double *rhs,             // (n) right hand side
    const double *d_ini,           // (n) first approximation for solution
    double *d,                     // (n) on output: solution
    double *workspace              // workspace vector of length (7 * n)
    )
{
  // workspace arrays
  double *r;                    // residual          !
  double *p;                    // temporary vector  !
  double *q;                    // temporary vector  !
  double *s;                    // temporary vector
  double *u;                    // temporary vector  !
  double *v;                    // temporary vector
  double *z;                    // temporary vector  !

  double d_ini_norm;            // initial approximation norm
  double rhs_norm;              // initial norm of right hand side
  double residual_norm;         // norm of current residual
  double stop_test;             // stopping criterion
  unsigned int iter;            // Output: number of iterations proceeded
  double masheps = 1.e-16;      // ANSI/IEEE 754-1985 floating point precision
  double min_for_division = 1.e-64;    // Minimal for division
  double omega = OMEGA;

  double c_1, alpha, beta;      // Algorithm variables
  double rho, rho_next;         // Temporary variable

  // initialize workspace arrays
  r = workspace;
  p = r + n;
  q = p + n;
  s = q + n;
  u = s + n;
  v = u + n;
  z = v + n;

  // d = d_ini
  copy_array (n, d_ini, d);

  d_ini_norm = e2_norm_array (n, d_ini);

  if (d_ini_norm > masheps)
    {
      // Non-zero initial approximation
      // Compute initial residual
      // r = A d
      mult_msr_matrix_vector (A, I, n, d, r);
      // make residual: r = rhs - A d
      sub_arrays (n, rhs, r);
      // Compute norm of residual
      residual_norm = e2_norm_array (n, r);
      // Compute norm of right hand side
      rhs_norm = e2_norm_array (n, rhs);
    }
  else
    {
      // Zero initial approximation
      // r = rhs
      copy_array (n, rhs, r);
      // Compute norm of residual
      residual_norm = e2_norm_array (n, r);
      // Compute norm of right hand side
      rhs_norm = residual_norm;
    }

  if (rhs_norm < masheps)
    //rhs_norm = masheps;
    rhs_norm = 1;

  stop_test = residual_norm / rhs_norm;
  printf ("\tit=%3d, residual = %e, rhs = %e\n", 0, residual_norm, rhs_norm);
  if (stop_test < ITPREC)
    return 0;   // solution found (in d copy of d_ini)


  ///****************************** START ALGORITHM ******************************

  iter = 1;

  //??
  apply_preconditioner_msr_vector (A, I, n, r, omega, r);
  rhs_norm = e2_norm_array (n, r);
  if (rhs_norm < masheps)
    rhs_norm = 1;
  //??end

  // Compute residual z = a_precond^{-1} r for preconditioned system B^{-1} Au = B^{-1} b
  apply_preconditioner_msr_vector (A, I, n, r, omega, z);
  apply_preconditioner_msr_matrix (A, I, n, omega);

  copy_array (n, z, r);
  copy_array (n, z, p);
  copy_array (n, z, u);
  set_e1 (z, n);

  // Compute rho = (z, r)
  rho = e2_scalar_product_array (n, z, r);

  // Iterative loop
  for (; iter <= ITMAX; iter++)
    {
      // v = A(p)
      mult_msr_matrix_vector (A, I, n, p, v);

      // Compute alpha = rho / (z, v)
      // c_1 = (z, v)
      c_1 = e2_scalar_product_array (n, z, v);
      if (fabs (rho) < min_for_division
          || fabs(c_1) < 1e-16)
        {
          printf ("Fatal error: acceleration algorithm breaks down.    err1\n");
          return -2;
        }
      alpha = rho / c_1;

      // q = u - alpha v
      linear_combination_1 (n, u, v, -alpha, q);

      // s = u + q
      sum_arrays2 (n, q, u, s);

      // d = d + alpha s
      linear_combination_1 (n, d, s, alpha, d);

      // v = A(s)
      mult_msr_matrix_vector (A, I, n, s, v);

      // r = r - alpha v
      linear_combination_1 (n, r, v, -alpha, r);

      // Compute new residual norm
      residual_norm = e2_norm_array (n, r);

      // Check stopping criterion                          <-----
      stop_test = residual_norm / rhs_norm;
      printf ("\tit=%3d, residual = %e\n", iter, residual_norm);
      if (stop_test < ITPREC)
        break;


      // Compute beta = (r, z) / rho
      rho_next = e2_scalar_product_array (n, r, z);
      if (fabs (rho_next) < min_for_division
          || fabs(rho) < 1e-16)
        {
          printf ("Fatal error: acceleration algorithm breaks down.    err2\n");
          return -3;
        }

      beta = rho_next / rho;

      // u = r + beta q
      linear_combination_1 (n, r, q, beta, u);

      // s = q + beta p
      linear_combination_1 (n, q, p, beta, s);

      // p = u + beta s
      linear_combination_1 (n, u, s, beta, p);

      // rho = rho_next
      rho = rho_next;
    }

  if (iter >= ITMAX)
    {
      // Convergence too slow or failed
      printf ("Fatal error: failure to converge in max %d iterations\n", ITMAX);

      return -10;
    }

  return iter;
}
