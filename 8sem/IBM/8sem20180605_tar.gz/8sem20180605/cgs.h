#ifndef CGS_H
#define CGS_H

void set_e1 (double *x, int n);

int solve_linear_system_cgs (
    double *A, const int *I, // sparse matrix, msr format
    unsigned int n,                // order of system
    const double *rhs,             // (n) right hand side
    const double *d_ini,           // (n) first approximation for solution
    double *d,                     // (n) on output: solution
    double *workspace              // workspace vector of length (7 * n)
    );

#endif // CGS_H
