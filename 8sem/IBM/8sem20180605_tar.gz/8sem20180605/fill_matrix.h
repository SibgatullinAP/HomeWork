#ifndef FILL_MATRIX_H
#define FILL_MATRIX_H

struct P_gas;
struct P_she;
struct P_nodes;
struct useful;
struct for_mu;

//static useful helper_one;
//static for_mu mu_helper_two;

int assemble_matrix (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                     int *N, int **I, double **A);

void my_set_len (double *A, int *I, int i, int count);
void my_set_entry (double *A, int *I, int i, int k, int j, double tmp);
void my_set_cmp (double *B, int i, double tmp);

void fill_0_inner (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                   useful *helper, for_mu *mum,
                   double *A, int *I, double *b,
                   int m, int mm, // equation
                   int time_step);

void fill_1_left_wall (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                       useful *helper, for_mu *mum,
                       double *A, int *I, double *b,
                       int m, int mm, // equation
                       int time_step);

void fill_2_right_wall (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                        useful *helper, for_mu *mum,
                        double *A, int *I, double *b,
                        int m, int mm, // equation
                        int time_step);

void fill_3_bottom (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                    useful *helper, for_mu *mum,
                    double *A, int *I, double *b,
                    int m, int mm, // equation
                    int time_step);

void fill_4_top (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 double *A, int *I, double *b,
                 int m, int mm, // equation
                 int time_step);
void fill_5 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
             useful *helper, for_mu *mum,
             double *A, int *I, double *b,
             int m, int mm, // equation
             int time_step);
void fill_6 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
             useful *helper, for_mu *mum,
             double *A, int *I, double *b,
             int m, int mm, // equation
             int time_step);
void fill_7 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
             useful *helper, for_mu *mum,
             double *A, int *I, double *b,
             int m, int mm, // equation
             int time_step);
void fill_8 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
             useful *helper, for_mu *mum,
             double *A, int *I, double *b,
             int m, int mm, // equation
             int time_step);
void fill_9 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               double *A, int *I, double *b,
               int m, int mm, // equation
               int time_step);
void fill_10 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                double *A, int *I, double *b,
                int m, int mm, // equation
                int time_step);
void fill_11 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                double *A, int *I, double *b,
                int m, int mm, // equation
                int time_step);
void fill_12 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                double *A, int *I, double *b,
                int m, int mm, // equation
                int time_step);

void fill_matrix (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                  useful *helper, for_mu *mum,
                  double *A, int *I, double *b, int time_step);

#endif // FILL_MATRIX_H
