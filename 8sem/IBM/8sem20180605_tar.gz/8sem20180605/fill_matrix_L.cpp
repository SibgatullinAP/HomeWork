#include <math.h>
#include <stdio.h>
#include "fill_matrix_L.h"
#include "params.h"
#include "nodes.h"
#include "useful.h"
#include "functions.h"
#include "laspack/qmatrix.h"

#define Const 1

// p.20-23
void fill_0_inner_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                     useful *helper, for_mu *mum,
                     QMatrix_L *A, Vector *b,
                     int m,  // node number
                     int mm, // equation number
                     int time_step)
{
  double *G = nodes->G, *V1 = nodes->V1, *V2 = nodes->V2;
  int *M0L = nodes->M0L, *M0R = nodes->M0R;
  int mmgL0, mmv1L0, mmv2L0, mmgR0, mmv1R0, mmv2R0,
      mmg0L, mmv10L, mmv20L, mmg0R, mmv10R, mmv20R;
  int ML = M0L[m], MR = M0R[m];
  double mu = p_g->mu;

  // mmg00 == mm
  mmgL0  = mm - 3;
  mmv1L0 = mm - 2;
  mmv2L0 = mm - 1;
  mmgR0  = mm + 3;
  mmv1R0 = mm + 4;
  mmv2R0 = mm + 5;

  mmg0L  = 3 * ML + 1;
  mmv10L = mmg0L + 1;
  mmv20L = mmv10L + 1;
  mmg0R  = 3 * MR + 1;
  mmv10R = mmg0R + 1;
  mmv20R = mmv10R + 1;

  double g00 = G[m];
  double v100 = V1[m];
  double v1L0 = V1[m - 1];
  double v1R0 = V1[m + 1];
  double v10L = V1[ML];
  double v10R = V1[MR];
  double v1LL = V1[ML - 1];
  double v1RL = V1[ML + 1];
  double v1LR = V1[MR - 1];
  double v1RR = V1[MR + 1];
  double v200 = V2[m];
  double v2L0 = V2[m - 1];
  double v2R0 = V2[m + 1];
  double v20L = V2[ML];
  double v20R = V2[MR];
  double v2LL = V2[ML - 1];
  double v2RL = V2[ML + 1];
  double v2LR = V2[MR - 1];
  double v2RR = V2[MR + 1];

  double thx = helper->thx, thy = helper->thy;
  double thx2 = helper->thx2, thy2 = helper->thy2;
  double thx32 = helper->thx32, thy32 = helper->thy32, thxy = helper->thxy;
  double thxx6 = helper->thxx6, thxx8 = helper->thxx8,
      thyy6 = helper->thyy6, thyy8 = helper->thyy8;
  double tau4 = helper->tau4, tau6 = helper->tau6,
      Max = helper->Max, May = helper->May;
  double MUv1 = mum->MUv1, MUv2 = mum->MUv2, MU8x = mum->MU8x, MU8y = mum->MU8y,
      MU6x = mum->MU6x, MU6y = mum->MU6y, MUM = mum->MUM;


  double tmp, tmp1;
  Q_SetLen (A, mm, 9);

  Q_SetEntry (A, mm, 0, mm, 4.);
  tmp = thx * (v100 + v1R0);
  Q_SetEntry (A, mm, 1, mmgR0, tmp);
  tmp = -thx * (v100 + v1L0);
  Q_SetEntry (A, mm, 2, mmgL0, tmp);
  tmp = thy * (v200 + v20R);
  Q_SetEntry (A, mm, 3, mmg0R, tmp);
  tmp = -thy * (v200 + v20L);
  Q_SetEntry (A, mm, 4, mmg0L, tmp);
  Q_SetEntry (A, mm, 5, mmv1R0, thx2);
  Q_SetEntry (A, mm, 6, mmv20R, thy2);
  Q_SetEntry (A, mm, 7, mmv1L0, -thx2);
  Q_SetEntry (A, mm, 8, mmv20L, -thy2);

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m], yy = nodes->Y[m];

  // b_mm
  tmp = g00 * (4. + thx * (v1R0 - v1L0) + thy * (v20R - v20L))
      + tau4 * Func_0 (tt, xx, yy);
  V_SetCmp (b, mm, tmp);


  mm++;
  Q_SetLen (A, mm, 7);
  Q_SetEntry (A, mm, 0, mm, MUv1);
  tmp = thx * (v100 + v1R0) - MU8x;
  Q_SetEntry (A, mm, 1, mmv1R0, tmp);
  tmp = thy32 * (v200 + v20R) - MU6y;
  Q_SetEntry (A, mm, 2, mmv10R, tmp);
  tmp = Max;
  Q_SetEntry (A, mm, 3, mmgL0, -tmp);
  Q_SetEntry (A, mm, 4, mmgR0, tmp);
  tmp = -thx * (v100 + v1L0) - MU8x;
  Q_SetEntry (A, mm, 5, mmv1L0, tmp);
  tmp = -thy32 * (v200 + v20L) - MU6y;
  Q_SetEntry (A, mm, 6, mmv10L, tmp);

  tmp1 = mu * exp (-g00);
  tmp = v100 * (6. + thy32 * (v20R - v20L))
      - (MUM - tmp1) * (  thxx8 * (v1R0 - 2 * v100 + v1L0)
                        + thyy6 * (v10R - 2 * v100 + v10L))
      + thxy * (v2RR + v2LL - v2RL - v2LR) * tmp1
      + tau6 * Func_1 (tt, xx, yy, p_g->p_rho, p_g->mu);
  V_SetCmp (b, mm, tmp);


  mm++;
  Q_SetLen (A, mm, 7);
  Q_SetEntry (A, mm, 0, mm, MUv2);
  tmp = thx32 * (v100 + v1R0) - MU6x;
  Q_SetEntry (A, mm, 1, mmv2R0, tmp);
  tmp = thy * (v200 + v20R) - MU8y;
  Q_SetEntry (A, mm, 2, mmv20R, tmp);
  tmp = May;
  Q_SetEntry (A, mm, 3, mmg0L, -tmp);
  Q_SetEntry (A, mm, 4, mmg0R, tmp);
  tmp = -thx32 * (v100 + v1L0) - MU6x;
  Q_SetEntry (A, mm, 5, mmv2L0, tmp);
  tmp = -thy * (v200 + v20L) - MU8y;
  Q_SetEntry (A, mm, 6, mmv20L, tmp);
  tmp = v200 * (6. + thx32 * (v1R0 - v1L0))
      - (MUM - tmp1) * (  thxx6 * (v2R0 - 2 * v200 + v2L0)
                        + thyy8 * (v20R - 2 * v200 + v20L))
      + thxy * (v1RR + v1LL - v1RL - v1LR) * tmp1
      + tau6 * Func_2 (tt, xx, yy, p_g->p_rho, p_g->mu);
  V_SetCmp (b, mm, tmp);
}

void fill_1_left_wall_L (P_gas *, P_she *p_s, P_nodes *nodes,
                         useful *, for_mu *,
                         QMatrix_L *A, Vector *b,
                         int m,  // node number
                         int mm, // equation number
                         int time_step)
{
  //double *G = nodes->G, *V1 = nodes->V1;
  int /*mmgR0, mmv1R0,*/ mmv100, mmv200;

  // mmg00 == mm
  mmv100 = mm + 1;
  mmv200 = mm + 2;
/*  mmgR0  = mm + 3;
  mmv1R0 = mm + 4;

  double g00 = G[m];
  double gR0 = G[m + 1];
  double g_2_m2 = G[m + 2];
  double g_3_m2 = G[m + 3];
  double v100 = V1[m];
  double v1R0 = V1[m + 1];
  double v1_2_m2 = V1[m + 2];
  double v1_3_m2 = V1[m + 3];

  double thx = helper->thx;
  double thx2 = helper->thx2;
  double tau2 = helper->tau2;

  double tmp;
  Q_SetLen (A, mm, 4);

  tmp = 2. - thx * v100;
  Q_SetEntry (A, mm, 0, mm, tmp);
  tmp = thx * v1R0;
  Q_SetEntry (A, mm, 1, mmgR0, tmp);
  Q_SetEntry (A, mm, 2, mmv1R0, thx2);
  Q_SetEntry (A, mm, 3, mmv100, -thx2);

  double tt = time_step * p_s->tau;
  double xx = 0, yy = nodes->Y[m];

  tmp = 2 * g00 + thx * g00 * (v1R0 - v100)
      + thx * (  g00 * v100
               - 2.5 * gR0 * v1R0
               + 2 * g_2_m2 * v1_2_m2
               - 0.5 * g_3_m2 * v1_3_m2
               + (2 - g00) * (  v100
                              - 2.5 * v1R0
                              + 2 * v1_2_m2
                              - 0.5 * v1_3_m2))
      + tau2 * Func_0 (tt, xx, yy);
  V_SetCmp (b, mm, tmp);
*/
  double tt = time_step * p_s->tau;
  double xx = 0, yy = nodes->Y[m];
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mm, Const);
  //V_SetCmp (b, mm, 0);
  V_SetCmp (b, mm, g (tt, xx, yy));


  // u1 = omega
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv100, Const);
  //V_SetCmp (b, mm, omega_u);
  V_SetCmp (b, mm, u1 (tt, xx, yy));

  // u2 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv200, Const);
  V_SetCmp (b, mm, 0);
}

void fill_2_right_wall_L (P_gas *, P_she *p_s, P_nodes *nodes,
                          useful *helper, for_mu *,
                          QMatrix_L *A, Vector *b,
                          int m,  // node number
                          int mm, // equation number
                          int time_step)
{
  double *G = nodes->G, *V1 = nodes->V1;
  int mmgL0, mmv1L0, mmv100, mmv200;

  // mmg00 == mm
  mmv100 = mm + 1;
  mmv200 = mm + 2;
  mmgL0  = mm - 3;
  mmv1L0 = mm - 2;

  double g00 = G[m];
  double gL0 = G[m - 1];
  double g_2_m2 = G[m - 2];
  double g_3_m2 = G[m - 3];
  double v100 = V1[m];
  double v1L0 = V1[m - 1];
  double v1_2_m2 = V1[m - 2];
  double v1_3_m2 = V1[m - 3];

  double tmp;
  Q_SetLen (A, mm, 4);

  double thx = helper->thx;
  double thx2 = helper->thx2;
  double tau2 = helper->tau2;

  tmp = 2. + thx * v100;
  Q_SetEntry (A, mm, 0, mm, tmp);
  tmp = - thx * v1L0;
  Q_SetEntry (A, mm, 1, mmgL0, tmp);
  Q_SetEntry (A, mm, 2, mmv100, thx2);
  Q_SetEntry (A, mm, 3, mmv1L0, -thx2);

  double tt = time_step * p_s->tau;
  double xx = 3 * M_PI, yy = nodes->Y[m];

  tmp = 2 * g00 + thx * g00 * (v100 - v1L0)
      - thx * (  g00 * v100
               - 2.5 * gL0 * v1L0
               + 2 * g_2_m2 * v1_2_m2
               - 0.5 * g_3_m2 * v1_3_m2
               + (2 - g00) * (  v100
                              - 2.5 * v1L0
                              + 2 * v1_2_m2
                              - 0.5 * v1_3_m2))
      + tau2 * Func_0 (tt, xx, yy);
  V_SetCmp (b, mm, tmp);

  // v1_(M,y) = v1_(M-1,y)
  mm++;
  //Q_SetLen (A, mm, 1);
  //Q_SetEntry (A, mm, 0, mmv100, Const);
  //tmp = 0;
  Q_SetLen (A, mm, 2);
  Q_SetEntry (A, mm, 0, mmv100, Const);
  Q_SetEntry (A, mm, 1, mmv1L0, -Const);
  // v1_M = v1_(M-1) + du1_dx * hx
  tmp = p_s->h_x * du1_dx (tt, xx, yy);
  V_SetCmp (b, mm, tmp);

  // v2 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv200, Const);
  V_SetCmp (b, mm, 0);
}

void fill_3_bottom_L (P_gas *, P_she *p_s, P_nodes *nodes,
                      useful *helper, for_mu *,
                      QMatrix_L *A, Vector *b,
                      int m,  // node number
                      int mm, // equation number
                      int time_step)
{
  double *G = nodes->G, *V2 = nodes->V2;
  int *M0R = nodes->M0R;
  int mmg0R, mmv20R, mmv100, mmv200;
  int MR = M0R[m];
  int MR_2 = M0R[MR];
  int MR_3 = M0R[MR_2];

  // mmg00 == mm
  mmv100 = mm + 1;
  mmv200 = mm + 2;
  mmg0R  = 3 * MR + 1;
  mmv20R = mmg0R + 2;

  double g00 = G[m];
  double g0R = G[MR];
  double g_m1_2 = G[MR_2];
  double g_m1_3 = G[MR_3];
  double v200 = V2[m];
  double v20R = V2[MR];
  double v2_m1_2 = V2[MR_2];
  double v2_m1_3 = V2[MR_3];

  double thy = helper->thy, thy2 = helper->thy2;
  double tau2 = helper->tau2;

  double tmp;
  Q_SetLen (A, mm, 4);

  tmp = 2. - thy * v200;
  Q_SetEntry (A, mm, 0, mm, tmp);
  tmp = thy * v20R;
  Q_SetEntry (A, mm, 1, mmg0R, tmp);
  Q_SetEntry (A, mm, 2, mmv20R, thy2);
  Q_SetEntry (A, mm, 3, mmv200, -thy2);

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m], yy = nodes->Y[m];

  tmp = 2 * g00 + thy * g00 * (v20R - v200)
      + thy * (  g00 * v200
               - 2.5 * g0R * v20R
               + 2 * g_m1_2 * v2_m1_2
               - 0.5 * g_m1_3 * v2_m1_3
               + (2 - g00) * (  v200
                              - 2.5 * v20R
                              + 2 * v2_m1_2
                              - 0.5 * v2_m1_3))
      + tau2 * Func_0 (tt, xx, yy);
  V_SetCmp (b, mm, tmp);

  // u1 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv100, Const);
  V_SetCmp (b, mm, 0);

  // u2 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv200, Const);
  V_SetCmp (b, mm, 0);
}

void fill_4_top_L (P_gas *, P_she *p_s, P_nodes *nodes,
                   useful *helper, for_mu *,
                   QMatrix_L *A, Vector *b,
                   int m,  // node number
                   int mm, // equation number
                   int time_step)
{
  double *G = nodes->G, *V2 = nodes->V2;
  int *M0L = nodes->M0L;
  int mmg0L, mmv20L, mmv100, mmv200;
  int ML = M0L[m];
  int ML_2 = M0L[ML];
  int ML_3 = M0L[ML_2];

  // mmg00 == mm
  mmv100 = mm + 1;
  mmv200 = mm + 2;
  mmg0L  = 3 * ML + 1;
  mmv20L = mmg0L + 2;

  double g00 = G[m];
  double g0L = G[ML];
  double g_m1_2 = G[ML_2];
  double g_m1_3 = G[ML_3];
  double v200 = V2[m];
  double v20L = V2[ML];
  double v2_m1_2 = V2[ML_2];
  double v2_m1_3 = V2[ML_3];

  double thy = helper->thy, thy2 = helper->thy2;
  double tau2 = helper->tau2;

  double tmp;
  Q_SetLen (A, mm, 4);

  tmp = 2. + thy * v200;
  Q_SetEntry (A, mm, 0, mm, tmp);
  tmp = - thy * v20L;
  Q_SetEntry (A, mm, 1, mmg0L, tmp);
  Q_SetEntry (A, mm, 2, mmv20L, -thy2);
  Q_SetEntry (A, mm, 3, mmv200, thy2);

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m], yy = 2 * M_PI;

  tmp = 2 * g00 + thy * g00 * (v200 - v20L)
      - thy * (  g00 * v200
               - 2.5 * g0L * v20L
               + 2 * g_m1_2 * v2_m1_2
               - 0.5 * g_m1_3 * v2_m1_3
               + (2 - g00) * (  v200
                              - 2.5 * v20L
                              + 2 * v2_m1_2
                              - 0.5 * v2_m1_3))
      + tau2 * Func_0 (tt, xx, yy);
  V_SetCmp (b, mm, tmp);

  // u1 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv100, Const);
  V_SetCmp (b, mm, 0);

  // u2 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv200, Const);
  V_SetCmp (b, mm, 0);
}

void fill_5_L (P_gas *, P_she *p_s, P_nodes *,
               useful *, for_mu *,
               QMatrix_L *A, Vector *b,
               int , // node number
               int mm, // equation number
               int time_step)
{
  // mmg00 == mm
  int mmv100 = mm + 1;
  int mmv200 = mm + 2;

  double tt = time_step * p_s->tau;
  double xx = 0, yy = 0;

  // g = 0 -> is known
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mm, Const);
  //V_SetCmp (b, mm, 0);
  V_SetCmp (b, mm, g (tt, xx, yy));

  // u1 = omega -> is known
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv100, Const);
  //V_SetCmp (b, mm, omega_u);
  V_SetCmp (b, mm, u1 (tt, xx, yy));

  // u2 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv200, Const);
  V_SetCmp (b, mm, 0);
}

void fill_6_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, // node number
               int mm, // equation number
               int time_step)
{
  return fill_2_right_wall_L (p_g, p_s,nodes, helper, mum,
                              A, b, m, mm, time_step);
}

void fill_7_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m,  // node number
               int mm, // equation number
               int time_step)
{
  fill_1_left_wall_L (p_g, p_s, nodes, helper, mum, A, b, m, mm, time_step);
  //fill_4_top_L (p_g, p_s, nodes, helper, mum, A, b, m, mm, time_step);
}

void fill_8_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m,  // node number
               int mm, // equation number
               int time_step)
{
  fill_2_right_wall_L (p_g, p_s, nodes, helper, mum, A, b, m, mm, time_step);
  //fill_4_top_L (p_g, p_s, nodes, helper, mum, A, b, m, mm, time_step);
}

// inner left wall --|
void fill_9_L (P_gas *, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *,
               QMatrix_L *A, Vector *b,
               int m, int mm, // equation
               int time_step)
{
  double *G = nodes->G, *V1 = nodes->V1;
  int mmgL0, mmv1L0, mmv100, mmv200;

  // mmg00 == mm
  mmv100 = mm + 1;
  mmv200 = mm + 2;
  mmgL0  = mm - 3;
  mmv1L0 = mm - 2;

  double g00 = G[m];
  double gL0 = G[m - 1];
  double g_2_m2 = G[m - 2];
  double g_3_m2 = G[m - 3];
  double v100 = V1[m];
  double v1L0 = V1[m - 1];
  double v1_2_m2 = V1[m - 2];
  double v1_3_m2 = V1[m - 3];

  double tmp;
  Q_SetLen (A, mm, 4);

  double thx = helper->thx;
  double thx2 = helper->thx2;
  double tau2 = helper->tau2;

  tmp = 2. + thx * v100;
  Q_SetEntry (A, mm, 0, mm, tmp);
  tmp = - thx * v1L0;
  Q_SetEntry (A, mm, 1, mmgL0, tmp);
  Q_SetEntry (A, mm, 2, mmv100, thx2);
  Q_SetEntry (A, mm, 3, mmv1L0, -thx2);

  double tt = time_step * p_s->tau;
  double xx = M_PI, yy = nodes->Y[m];

  tmp = 2 * g00 + thx * g00 * (v100 - v1L0)
      - thx * (g00 * v100
               - 2.5 * gL0 * v1L0
               + 2 * g_2_m2 * v1_2_m2
               - 0.5 * g_3_m2 * v1_3_m2
               + (2 - g00) * (  v100
                              - 2.5 * v1L0
                              + 2 * v1_2_m2
                              - 0.5 * v1_3_m2))
      + tau2 * Func_0 (tt, xx, yy);
  V_SetCmp (b, mm, tmp);

  // v1 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv100, Const);
  V_SetCmp (b, mm, 0);

  // v2 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv200, Const);
  V_SetCmp (b, mm, 0);
}

// inner right wall |--
void fill_10_L (P_gas *, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *,
                QMatrix_L *A, Vector *b,
                int m, int mm, // equation
                int time_step)
{
  double *G = nodes->G, *V1 = nodes->V1;
  int mmgR0, mmv1R0, mmv100, mmv200;

  // mmg00 == mm
  mmv100 = mm + 1;
  mmv200 = mm + 2;
  mmgR0  = mm + 3;
  mmv1R0 = mm + 4;

  double g00 = G[m];
  double gR0 = G[m + 1];
  double g_2_m2 = G[m + 2];
  double g_3_m2 = G[m + 3];
  double v100 = V1[m];
  double v1R0 = V1[m + 1];
  double v1_2_m2 = V1[m + 2];
  double v1_3_m2 = V1[m + 3];

  double thx = helper->thx;
  double thx2 = helper->thx2;
  double tau2 = helper->tau2;

  double tmp;
  Q_SetLen (A, mm, 4);

  tmp = 2. - thx * v100;
  Q_SetEntry (A, mm, 0, mm, tmp);
  tmp = thx * v1R0;
  Q_SetEntry (A, mm, 1, mmgR0, tmp);
  Q_SetEntry (A, mm, 2, mmv1R0, thx2);
  Q_SetEntry (A, mm, 3, mmv100, -thx2);

  double tt = time_step * p_s->tau;
  double xx = 2 * M_PI, yy = nodes->Y[m];

  tmp = 2 * g00 + thx * g00 * (v1R0 - v100)
      + thx * ( g00 * v100
               - 2.5 * gR0 * v1R0
               + 2 * g_2_m2 * v1_2_m2
               - 0.5 * g_3_m2 * v1_3_m2
               + (2 - g00) * (  v100
                              - 2.5 * v1R0
                              + 2 * v1_2_m2
                              - 0.5 * v1_3_m2))
      + tau2 * Func_0 (tt, xx, yy);
  V_SetCmp (b, mm, tmp);

  // u1 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv100, Const);
  V_SetCmp (b, mm, 0);

  // u2 = 0
  mm++;
  Q_SetLen (A, mm, 1);
  Q_SetEntry (A, mm, 0, mmv200, Const);
  V_SetCmp (b, mm, 0);
}

void fill_11_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                QMatrix_L *A, Vector *b,
                int m, int mm, // equation
                int time_step)
{
  fill_9_L (p_g, p_s, nodes, helper, mum, A, b, m, mm, time_step);
}

void fill_12_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                QMatrix_L *A, Vector *b,
                int m, int mm, // equation
                int time_step)
{
  fill_10_L (p_g, p_s, nodes, helper, mum, A, b, m, mm, time_step);
}

/////////////////////////////////////////////////////////////////////
void fill_matrix_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                    useful *helper, for_mu *mum,
                    QMatrix_L *A, Vector *b, int time_step)
{
  int i, mm;
  int Dim = p_s->Dim;
  int *st = nodes->st;

  for (i = 0, mm = 1; i < Dim; i++, mm += 3)
    {
      int state = st[i];
      switch (state)
        {
        case (0):
          fill_0_inner_L (p_g, p_s, nodes, helper, mum,
                          A, b, i, mm, time_step);
          break;
        case (1):
          fill_1_left_wall_L (p_g, p_s, nodes, helper, mum,
                              A, b, i, mm, time_step);
          break;
        case (2):
          fill_2_right_wall_L (p_g, p_s, nodes, helper, mum,
                               A, b, i, mm, time_step);
          break;
        case (3):
          fill_3_bottom_L (p_g, p_s, nodes, helper, mum,
                           A, b, i, mm, time_step);
          break;
        case (4):
          fill_4_top_L (p_g, p_s, nodes, helper, mum,
                        A, b, i, mm, time_step);
          break;
        case (5):
          fill_5_L (p_g, p_s, nodes, helper, mum,
                    A, b, i, mm, time_step);
          break;
        case (6):
          fill_6_L (p_g, p_s, nodes, helper, mum,
                    A, b, i, mm, time_step);
          break;
        case (7):
          fill_7_L (p_g, p_s, nodes, helper, mum,
                    A, b, i, mm, time_step);
          break;
        case (8):
          fill_8_L (p_g, p_s, nodes, helper, mum,
                    A, b, i, mm, time_step);
          break;
        case (9):
          fill_9_L (p_g, p_s, nodes, helper, mum,
                    A, b, i, mm, time_step);
          break;
        case (10):
          fill_10_L (p_g, p_s, nodes, helper, mum,
                     A, b, i, mm, time_step);
          break;
        case (11):
          fill_11_L (p_g, p_s, nodes, helper, mum,
                     A, b, i, mm, time_step);
          break;
        case (12):
          fill_12_L (p_g, p_s, nodes, helper, mum,
                     A, b, i, mm, time_step);
          break;
        default:
          printf ("ERROR: unknown state in fill_matix!\n");
          return;
        }

      //printf ("d-%d %d: %f\n", mm, state, Q_GetEl (A, mm, mm));
      //printf ("d-%d %d: %f\n", mm + 1, state, Q_GetEl (A, mm + 1, mm + 1));
      //printf ("d-%d %d: %f\n", mm + 2, state, Q_GetEl (A, mm + 2, mm + 2));
    }
}
