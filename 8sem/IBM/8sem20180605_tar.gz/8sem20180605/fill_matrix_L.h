#ifndef FILL_MATRIX_L_H
#define FILL_MATRIX_L_H

#include "laspack/qmatrix.h"

struct P_gas;
struct P_she;
struct P_nodes;
struct useful;
struct for_mu;

void fill_0_inner_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                     useful *helper, for_mu *mum,
                     QMatrix_L *A, Vector *b,
                     int m, int mm, // equation
                     int time_step);

void fill_1_left_wall_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                       useful *helper, for_mu *mum,
                       QMatrix_L *A, Vector *b,
                       int m, int mm, // equation
                       int time_step);

void fill_2_right_wall_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                        useful *helper, for_mu *mum,
                        QMatrix_L *A, Vector *b,
                        int m, int mm, // equation
                        int time_step);

void fill_3_bottom_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                    useful *helper, for_mu *mum,
                    QMatrix_L *A, Vector *b,
                    int m, int mm, // equation
                    int time_step);

void fill_4_top_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int mm, // equation
                 int time_step);
void fill_5_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int mm, // equation
               int time_step);
void fill_6_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int mm, // equation
               int time_step);
void fill_7_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int mm, // equation
               int time_step);
void fill_8_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int mm, // equation
               int time_step);
void fill_9_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int mm, // equation
               int time_step);
void fill_10_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                QMatrix_L *A, Vector *b,
                int m, int mm, // equation
                int time_step);
void fill_11_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                QMatrix_L *A, Vector *b,
                int m, int mm, // equation
                int time_step);
void fill_12_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                useful *helper, for_mu *mum,
                QMatrix_L *A, Vector *b,
                int m, int mm, // equation
                int time_step);

void fill_matrix_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                    useful *helper, for_mu *mum,
                    QMatrix_L *A, Vector *b, int time_step);

#endif // FILL_MATRIX_L_H
