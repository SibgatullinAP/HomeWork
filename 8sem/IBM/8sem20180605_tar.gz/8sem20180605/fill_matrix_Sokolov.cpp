#include <math.h>
#include <stdio.h>
#include "fill_matrix_Sokolov.h"
#include "params.h"
#include "nodes.h"
#include "useful.h"
#include "functions.h"
#include "laspack/qmatrix.h"
#include "settings.h"

#define Const 1
extern bool is_known_func;

double g_s (double g0, double gR)
{
  return 0.5 * (gR + g0);
}

double g_s_bar (double g0, double gL)
{
  return g_s (gL, g0);
}

double get_half_value (double g1, double g2)
{
  return 0.5 * (g1 + g2);
}

double segment_fabs (double plus, double minus)
{
  return plus + fabs (plus) - minus + fabs (minus);
}
///////////////////////////////////////////////////////////////////////////////

void fill_H_S_0 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0L = nodes->M0L, *M0R = nodes->M0R;
  int mh00, mhR0, mh0R, mhL0, mh0L;

  int ML_half = nodes->get_half_by_m (M0L[m]);
  int MR_half = nodes->get_half_by_m (M0R[m]);

  mh00 = m_half + 1; // 1...M
  mhL0 = mh00 - 1;
  mhR0 = mh00 + 1;
  mh0R = MR_half + 1;
  mh0L = ML_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_HR0 = thx05 * (VT1R0 - fabs (VT1R0));
  double ah_H0R = thy05 * (VT20R - fabs (VT20R));
  double ah_HL0 = -thx05 * (VT100 + fabs (VT100));
  double ah_H0L = -thy05 * (VT200 + fabs (VT200));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 5);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mhR0, ah_HR0);
  Q_SetEntry (A, mh00, 2, mh0R, ah_H0R);
  Q_SetEntry (A, mh00, 3, mhL0, ah_HL0);
  Q_SetEntry (A, mh00, 4, mh0L, ah_H0L);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_2 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0L = nodes->M0L, *M0R = nodes->M0R;
  int mh00, mh0R, mhL0, mh0L;

  int ML_half = nodes->get_half_by_m (M0L[m]);
  int MR_half = nodes->get_half_by_m (M0R[m]);

  mh00 = m_half + 1; // 1...M
  mhL0 = mh00 - 1;
  mh0R = MR_half + 1;
  mh0L = ML_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_H0R = thy05 * (VT20R - fabs (VT20R));
  double ah_HL0 = -thx05 * (VT100 + fabs (VT100));
  double ah_H0L = -thy05 * (VT200 + fabs (VT200));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 4);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mh0R, ah_H0R);
  Q_SetEntry (A, mh00, 2, mhL0, ah_HL0);
  Q_SetEntry (A, mh00, 3, mh0L, ah_H0L);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_3 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0R = nodes->M0R;
  int mh00, mhR0, mh0R, mhL0;

  int MR_half = nodes->get_half_by_m (M0R[m]);

  mh00 = m_half + 1; // 1...M
  mhL0 = mh00 - 1;
  mhR0 = mh00 + 1;
  mh0R = MR_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_HR0 = thx05 * (VT1R0 - fabs (VT1R0));
  double ah_H0R = thy05 * (VT20R - fabs (VT20R));
  double ah_HL0 = -thx05 * (VT100 + fabs (VT100));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 4);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mhR0, ah_HR0);
  Q_SetEntry (A, mh00, 2, mh0R, ah_H0R);
  Q_SetEntry (A, mh00, 3, mhL0, ah_HL0);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_4 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0L = nodes->M0L;
  int mh00, mhR0, mhL0, mh0L;

  int ML_half = nodes->get_half_by_m (M0L[m]);

  mh00 = m_half + 1; // 1...M
  mhL0 = mh00 - 1;
  mhR0 = mh00 + 1;
  mh0L = ML_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_HR0 = thx05 * (VT1R0 - fabs (VT1R0));
  double ah_HL0 = -thx05 * (VT100 + fabs (VT100));
  double ah_H0L = -thy05 * (VT200 + fabs (VT200));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 4);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mhR0, ah_HR0);
  Q_SetEntry (A, mh00, 2, mhL0, ah_HL0);
  Q_SetEntry (A, mh00, 3, mh0L, ah_H0L);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_6 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0R = nodes->M0R;
  int mh00, mh0R, mhL0;

  int MR_half = nodes->get_half_by_m (M0R[m]);

  mh00 = m_half + 1; // 1...M
  mhL0 = mh00 - 1;
  mh0R = MR_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_H0R = thy05 * (VT20R - fabs (VT20R));
  double ah_HL0 = -thx05 * (VT100 + fabs (VT100));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 3);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mh0R, ah_H0R);
  Q_SetEntry (A, mh00, 2, mhL0, ah_HL0);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_7 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0L = nodes->M0L;
  int mh00, mhR0, mh0L;

  int ML_half = nodes->get_half_by_m (M0L[m]);

  mh00 = m_half + 1; // 1...M
  mhR0 = mh00 + 1;
  mh0L = ML_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_HR0 = thx05 * (VT1R0 - fabs (VT1R0));
  double ah_H0L = -thy05 * (VT200 + fabs (VT200));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 5);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mhR0, ah_HR0);
  Q_SetEntry (A, mh00, 4, mh0L, ah_H0L);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_8 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0L = nodes->M0L;
  int mh00, mhL0, mh0L;

  int ML_half = nodes->get_half_by_m (M0L[m]);

  mh00 = m_half + 1; // 1...M
  mhL0 = mh00 - 1;
  mh0L = ML_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_HL0 = -thx05 * (VT100 + fabs (VT100));
  double ah_H0L = -thy05 * (VT200 + fabs (VT200));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 3);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mhL0, ah_HL0);
  Q_SetEntry (A, mh00, 2, mh0L, ah_H0L);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_10 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0L = nodes->M0L, *M0R = nodes->M0R;
  int mh00, mhR0, mh0R, mh0L;

  int ML_half = nodes->get_half_by_m (M0L[m]);
  int MR_half = nodes->get_half_by_m (M0R[m]);

  mh00 = m_half + 1; // 1...M
  mhR0 = mh00 + 1;
  mh0R = MR_half + 1;
  mh0L = ML_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_HR0 = thx05 * (VT1R0 - fabs (VT1R0));
  double ah_H0R = thy05 * (VT20R - fabs (VT20R));
  double ah_H0L = -thy05 * (VT200 + fabs (VT200));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 4);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mhR0, ah_HR0);
  Q_SetEntry (A, mh00, 2, mh0R, ah_H0R);
  Q_SetEntry (A, mh00, 3, mh0L, ah_H0L);

  V_SetCmp (b, mh00, bh);
}

void fill_H_S_12 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val)
{
  int *M0R = nodes->M0R;
  int mh00, mhR0, mh0R;

  int MR_half = nodes->get_half_by_m (M0R[m]);

  mh00 = m_half + 1; // 1...M
  mhR0 = mh00 + 1;
  mh0R = MR_half + 1;

  double H00 = val[0];
  double V100 = val[1];
  double V1R0 = val[2];
  double V10R = val[3];
  double V1RR = val[4];
  double V200 = val[5];
  double V2R0 = val[6];
  double V20R = val[7];
  double V2RR = val[8];

  double VT100 = g_s (V100, V10R);
  double VT1R0 = g_s (V1R0, V1RR);
  double VT200 = g_s (V200, V2R0);
  double VT20R = g_s (V20R, V2RR);

  double thx05 = helper->thx05, thy05 = helper->thy05;
  double tau = p_s->tau;

  double ah_H00 = 1 + thx05 * segment_fabs (VT1R0, VT100)
                    + thy05 * segment_fabs (VT20R, VT200);
  double ah_HR0 = thx05 * (VT1R0 - fabs (VT1R0));
  double ah_H0R = thy05 * (VT20R - fabs (VT20R));

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m] + p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  double bh = H00
      + tau * Func_0 (tt, xx, yy);

  Q_SetLen (A, mh00, 3);
  Q_SetEntry (A, mh00, 0, mh00, ah_H00);
  Q_SetEntry (A, mh00, 1, mhR0, ah_HR0);
  Q_SetEntry (A, mh00, 2, mh0R, ah_H0R);

  V_SetCmp (b, mh00, bh);
}
/*
///////////////////////////////////////////////////////////////////////////////
void fill_H_S_1 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step)
{
  int mh00 = m_half + 1; // 1...M

  double tt = time_step * p_s->tau;
  double xx = p_s->h_x * 0.5;
  double yy = nodes->Y[m] + p_s->h_y * 0.5;

  Q_SetLen (A, mh00, 1);
  Q_SetEntry (A, mh00, 0, mh00, Const);

  V_SetCmp (b, mh00, rho (tt, xx, yy));
}*/

///////////////////////////////////////////////////////////////////////////////

double get_HT00 (int m, P_nodes *nodes, double *H)
{
  int m_half = nodes->get_half_by_m (m);
  int L = nodes->M0L[m];
  int L_half = nodes->get_half_by_m (L);

  double H00 = H[m_half];
  double HL0 = H[m_half - 1];
  double H0L = H[L_half];
  double HLL = H[L_half - 1];

  double res = H00 + HL0 + H0L + HLL;
  res /= 4;
  return res;
}

// ////////////////////////////////////////////////////////
bool is_R0_H (int m_v, P_nodes *nodes)
{
  int st_R = nodes->st [m_v + 1];
  if (st_R == 0 || st_R == 3 || st_R == 4)
    return true;
  return false;
}

bool is_D0_H (int m_v, P_nodes *nodes)
{
  int st_L = nodes->st [m_v - 1];
  if (st_L == 0 || st_L == 3 || st_L == 4)
    return true;
  return false;
}

void fill_V_S_0 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int time_step)
{
  double *H = nodes->G, *V1 = nodes->V1, *V2 = nodes->V2;
  int *M0L = nodes->M0L, *M0R = nodes->M0R;
  int ML = M0L[m], MR = M0R[m];

  int mv100 = 2 * m + 1;
  int mv1R0 = mv100 + 2;
  int mv1L0 = mv100 - 2;
  int mv10R = 2 * MR + 1;
  int mv10L = 2 * ML + 1;

  int mv200 = mv100 + 1;
  int mv2R0 = mv1R0 + 1;
  int mv2L0 = mv1L0 + 1;
  int mv20R = mv10R + 1;
  int mv20L = mv10L + 1;

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m], yy = nodes->Y[m];

  bool is_1_H_L0 = (nodes->st[m - 1] == 1) ? true : false;
  int m_half = nodes->get_half_by_m (m);
  int L_half = nodes->get_half_by_m (ML);
  int R_half = nodes->get_half_by_m (MR);
  int DL_half = nodes->get_half_by_m (M0L[ML]);
  bool is_R0 = is_R0_H (m, nodes);
  bool is_0R = (R_half == -1) ? false : true;
  bool is_D0 = is_D0_H (m, nodes);
  bool is_0D = (DL_half == -1) ? false : true;

  double H00 = H[m_half];
  double HL0 = H[m_half - 1];
  double HR0 = is_R0 ? H[m_half + 1] : 0;
  double HDL0 = is_D0 ? H[m_half - 2] :
      (is_1_H_L0 ? rho (tt, -p_s->h_x * 0.5, yy + p_s->h_y * 0.5) : 0);
  double H0L = H[L_half];
  double HLL = H[L_half - 1];
  double HRL = is_R0 ? H[L_half + 1] : 0;
  double HDLL = is_D0 ? H[L_half - 2] :
      (is_1_H_L0 ? rho (tt, -p_s->h_x * 0.5, yy - p_s->h_y * 0.5) : 0);
  double H0DL = is_0D ? H[DL_half] : 0;
  double HLDL = is_0D ? H[DL_half - 1] : 0;
  double H0R = is_0R ? H[R_half] : 0;
  double HLR = is_0R ? H[R_half - 1] : 0;


  double V100 = V1[m];
  double V1R0 = V1[m + 1];
  double V1L0 = V1[m - 1];
  double V10R = V1[MR];
  double V10L = V1[ML];
  double V1RR = V1[MR + 1];
  double V1LL = V1[ML - 1];
  double V1LR = V1[MR - 1];
  double V1RL = V1[ML + 1];
  double V200 = V2[m];
  double V2R0 = V2[m + 1];
  double V2L0 = V2[m - 1];
  double V20R = V2[MR];
  double V20L = V2[ML];
  double V2RR = V2[MR + 1];
  double V2LL = V2[ML - 1];
  double V2LR = V2[MR - 1];
  double V2RL = V2[ML + 1];

  double HT00 = get_HT00 (m, nodes, H);
  double HT00_OLD = get_HT00 (m, nodes, nodes->H_half_old);
  double H100 = g_s_bar (H00, H0L);
  double H1L0 = g_s_bar (HL0, HLL);
  double H1R0 = g_s_bar (HR0, HRL);
  double H1D0 = g_s_bar (HDL0, HDLL);
  double H200 = g_s_bar (H00, HL0);
  double H20L = g_s_bar (H0L, HLL);
  double H20R = g_s_bar (H0R, HLR);
  double H20D = g_s_bar (H0DL, HLDL);

  double tau = p_s->tau, h_x = p_s->h_x, h_y = p_s->h_y;
  double thx025 = helper->thx025, thy025 = helper->thy025;
  double MUv1S = mum->MUv1S, MUv2S = mum->MUv2S,
      MUxS43 = mum->MUxS43, MUyS43 = mum->MUyS43,
      MUxS = mum->MUxS, MUyS = mum->MUyS,
      MUxyS = mum->MUxyS, MUg = mum->MUg;

  double av1_V100 = HT00
      + thx025 * (
          H100 * segment_fabs (V1R0, V100)
        + H1L0 * segment_fabs (V100, V1L0))
      + MUv1S;
  double av1_V200 = thy025 * (  H200 * segment_fabs (V10R, V100)
                              + H20L * segment_fabs (V100, V10L));
  double av1_V1R0 = thx025 * (  H100 * (V100 - fabs (V100))
                              + H1R0 * (V1R0 - fabs (V1R0)))
      - MUxS43;
  double av1_V20R = thy025 * (  H200 * (V100 - fabs (V100))
                              + H20R * (V10R - fabs (V10R)));
  double av1_V1L0 = - thx025 * (  H1L0 * (V100 + fabs (V100))
                                + H1D0 * (V1L0 + fabs (V1L0)))
      - MUxS43;
  double av1_V20L = - thy025 * (  H20L * (V100 + fabs (V100))
                                + H20D * (V10L + fabs (V10L)));
  double av1_V10R = - MUyS;
  double av1_V10L = - MUyS;
  double bv1 = HT00_OLD * V100
      - (MUg * tau / ((MUg - 1) * h_x)) * HT00
        * (pow (H100, MUg - 1) - pow (H1L0, MUg - 1))
      + MUxyS * (V2LL - V2LR - V2RL + V2RR)
      + tau * Func_1_S (tt, xx, yy, p_g->p_rho_1, p_g->mu) * HT00;

  Q_SetLen (A, mv100, 8);
  Q_SetEntry (A, mv100, 0, mv100, av1_V100);
  Q_SetEntry (A, mv100, 1, mv200, av1_V200);
  Q_SetEntry (A, mv100, 2, mv1R0, av1_V1R0);
  Q_SetEntry (A, mv100, 3, mv20R, av1_V20R);
  Q_SetEntry (A, mv100, 4, mv1L0, av1_V1L0);
  Q_SetEntry (A, mv100, 5, mv20L, av1_V20L);
  Q_SetEntry (A, mv100, 6, mv10R, av1_V10R);
  Q_SetEntry (A, mv100, 7, mv10L, av1_V10L);

  V_SetCmp (b, mv100, bv1);


  // av2
  double av2_V200 = HT00
      + thy025 * (  H200 * segment_fabs (V20R, V200)
                  + H20L * segment_fabs (V200, V20L))
      + MUv2S;
  double av2_V100 = thx025 * (  H100 * segment_fabs (V2R0, V200)
                              + H1L0 * segment_fabs (V200, V2L0));
  double av2_V20R = thy025 * (  H200 * (V200 - fabs (V200))
                              + H20R * (V20R - fabs (V20R)))
      - MUyS43;
  double av2_V1R0 = thx025 * (  H100 * (V200 - fabs (V200))
                              + H1R0 * (V2R0 - fabs (V2R0)));
  double av2_V20L = - thy025 * (  H20L * (V200 + fabs (V200))
                                + H20D * (V20L + fabs (V20L)))
      - MUyS43;
  double av2_V1L0 = - thy025 * (  H1L0 * (V200 + fabs (V200))
                                + H1D0 * (V2L0 + fabs (V2L0)));
  double av2_V2R0 = - MUxS;
  double av2_V2L0 = - MUxS;
  double bv2 = HT00_OLD * V200
      - (MUg * tau / ((MUg - 1) * h_y)) * HT00
        * (pow (H200, MUg - 1) - pow (H20L, MUg - 1))
      + MUxyS * (V1LL - V1LR - V1RL + V1RR)
      + tau * Func_2_S (tt, xx, yy, p_g->p_rho_1, p_g->mu) * HT00;

  Q_SetLen (A, mv200, 8);
  Q_SetEntry (A, mv200, 0, mv200, av2_V200);
  Q_SetEntry (A, mv200, 1, mv100, av2_V100);
  Q_SetEntry (A, mv200, 2, mv20R, av2_V20R);
  Q_SetEntry (A, mv200, 3, mv1R0, av2_V1R0);
  Q_SetEntry (A, mv200, 4, mv20L, av2_V20L);
  Q_SetEntry (A, mv200, 5, mv1L0, av2_V1L0);
  Q_SetEntry (A, mv200, 6, mv2R0, av2_V2R0);
  Q_SetEntry (A, mv200, 7, mv2L0, av2_V2L0);

  V_SetCmp (b, mv200, bv2);
}

void fill_V_S_1 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int time_step)
{
  int mv100 = 2 * m + 1;
  int mv200 = mv100 + 1;

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m], yy = nodes->Y[m];

  // u1 = omega
  Q_SetLen (A, mv100, 1);
  Q_SetEntry (A, mv100, 0, mv100, Const);
  V_SetCmp (b, mv100, u1 (tt, xx, yy));

  // v2 = 0
  Q_SetLen (A, mv200, 1);
  Q_SetEntry (A, mv200, 0, mv200, Const);
  V_SetCmp (b, mv200, 0);
}

void fill_V_S_2 (P_gas *, P_she *p_s, P_nodes *nodes,
                 useful *, for_mu *,
                 QMatrix_L *A, Vector *b,
                 int m, int time_step)
{
  int mv100 = 2 * m + 1;
  int mv1L0 = mv100 - 2;
  int mv200 = mv100 + 1;

  double tt = time_step * p_s->tau;
  double xx = nodes->X[m], yy = nodes->Y[m];

  // v1_(M,y) = v1_(M-1,y)
  Q_SetLen (A, mv100, 2);
  Q_SetEntry (A, mv100, 0, mv100, Const);
  Q_SetEntry (A, mv100, 1, mv1L0, -Const);
  // v1_M = v1_(M-1) + du1_dx * hx
  double tmp = p_s->h_x * du1_dx (tt, xx, yy);
  V_SetCmp (b, mv100, tmp);

  // v2 = 0
  Q_SetLen (A, mv200, 1);
  Q_SetEntry (A, mv200, 0, mv200, Const);
  V_SetCmp (b, mv200, 0);
}

void fill_V_S_default (P_gas *, P_she *, P_nodes *,
                       useful *, for_mu *,
                       QMatrix_L *A, Vector *b,
                       int m, int )
{
  // v2 = v1 = 0
  int mv100 = 2 * m + 1;
  int mv200 = mv100 + 1;

  Q_SetLen (A, mv100, 1);
  Q_SetEntry (A, mv100, 0, mv100, Const);
  V_SetCmp (b, mv100, 0);

  Q_SetLen (A, mv200, 1);
  Q_SetEntry (A, mv200, 0, mv200, Const);
  V_SetCmp (b, mv200, 0);
}

///////////////////////////////////////////////////////////////////////////////

void fill_val_array (int m_main, int m_half, P_nodes *nodes,
                     double *val)
{
  double *V1 = nodes->V1, *V2 = nodes->V2;
  int *M0R = nodes->M0R;
  int MR = M0R[m_main];

  double V100 = V1[m_main];
  double V1R0 = V1[m_main + 1];
  double V10R = V1[MR];
  double V1RR = V1[MR + 1];
  double V200 = V2[m_main];
  double V2R0 = V2[m_main + 1];
  double V20R = V2[MR];
  double V2RR = V2[MR + 1];

  val[0] = nodes->G[m_half];
  val[1] = V100;
  val[2] = V1R0;
  val[3] = V10R;
  val[4] = V1RR;
  val[5] = V200;
  val[6] = V2R0;
  val[7] = V20R;
  val[8] = V2RR;
}

void fill_matrix_H_Sokolov (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                            useful *helper, for_mu *mum,
                            QMatrix_L *A, Vector *b, int time_step)
{
  int i;
  int half_Dim = nodes->half_Dim;
  int *half_st = nodes->half_st;
  double val[9];

  for (i = 0; i < half_Dim; i++)
    {
      int m = nodes->get_m_by_half (i);
      fill_val_array (m, i, nodes, val);

      int half_state = half_st[i];
      switch (half_state)
        {
        case (0):
          fill_H_S_0 (p_g, p_s, nodes, helper, mum,
                      A, b, m, i, time_step, val);
          break;
        case (2):
          fill_H_S_2 (p_g, p_s, nodes, helper, mum,
                      A, b, m, i, time_step, val);
          break;
        case (3):
          fill_H_S_3 (p_g, p_s, nodes, helper, mum,
                      A, b, m, i, time_step, val);
          break;
        case (4):
          fill_H_S_4 (p_g, p_s, nodes, helper, mum,
                      A, b, m, i, time_step, val);
          break;
        case (6):
          fill_H_S_6 (p_g, p_s, nodes, helper, mum,
                      A, b, m, i, time_step, val);
          break;
        case (7):
          fill_H_S_7 (p_g, p_s, nodes, helper, mum,
                      A, b, m, i, time_step, val);
          break;
        case (8):
          fill_H_S_8 (p_g, p_s, nodes, helper, mum,
                      A, b, m, i, time_step, val);
          break;
        case (1):
        case (10):
          fill_H_S_10 (p_g, p_s, nodes, helper, mum,
                       A, b, m, i, time_step, val);
          break;
        case (12):
          fill_H_S_12 (p_g, p_s, nodes, helper, mum,
                       A, b, m, i, time_step, val);
          break;
        default:
          printf ("ERROR: unknown state in fill_matix_H_Sokolov %d!\n", half_state);
          return;
        }
    }
}

void fill_matrix_V_Sokolov (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                            useful *helper, for_mu *mum,
                            QMatrix_L *A, Vector *b, int time_step)
{
  int i;
  int Dim = p_s->Dim;
  int *st = nodes->st;

  for (i = 0; i < Dim; i++)
    {
      int state = st[i];
      switch (state)
        {
        case (0):
          {
          double HT00 = get_HT00 (i, nodes, nodes->G);
          if (fabs (HT00) < 1e-8)
            {
              fill_V_S_default (p_g, p_s, nodes, helper, mum,
                                A, b, i, time_step);
              break;
            }

          fill_V_S_0 (p_g, p_s, nodes, helper, mum,
                      A, b, i, time_step);
          break;
          }
        case (1):
          fill_V_S_1 (p_g, p_s, nodes, helper, mum,
                      A, b, i, time_step);
          break;
        case (2):
          fill_V_S_2 (p_g, p_s, nodes, helper, mum,
                      A, b, i, time_step);
          break;
        case (3):
        case (4):
        case (5):
        case (6):
        case (7):
        case (8):
        case (9):
        case (10):
        case (11):
        case (12):
          fill_V_S_default (p_g, p_s, nodes, helper, mum,
                            A, b, i, time_step);
          break;
        default:
          printf ("ERROR: unknown state in fill_matix!\n");
          return;
        }

      //printf ("d-%d %d: %f\n", m, state, Q_GetEl (A, m, m));
      //printf ("d-%d %d: %f\n", m + 1, state, Q_GetEl (A, m + 1, m + 1));
      //printf ("d-%d %d: %f\n", m + 2, state, Q_GetEl (A, m + 2, m + 2));
    }
}
