#ifndef FILL_MATRIX_SOKOLOV_H
#define FILL_MATRIX_SOKOLOV_H

#include "laspack/qmatrix.h"

struct P_gas;
struct P_she;
struct P_nodes;
struct useful;
struct for_mu;

double get_half_value (double g1, double g2);

void fill_H_S_0 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_2 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_3 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_4 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_6 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_7 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_8 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_10 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);
void fill_H_S_12 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step, double *val);

void fill_H_S_1 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                 useful *helper, for_mu *mum,
                 QMatrix_L *A, Vector *b,
                 int m, int m_half, int time_step);

double get_HT00 (int m, P_nodes *nodes, double *H);

void fill_V_S_0 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int time_step);
void fill_V_S_1 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int time_step);
void fill_V_S_2 (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               useful *helper, for_mu *mum,
               QMatrix_L *A, Vector *b,
               int m, int time_step);
void fill_V_S_default (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                       useful *helper, for_mu *mum,
                       QMatrix_L *A, Vector *b,
                        int m, int time_step);

void fill_val_array (int m_main, int m_half, P_nodes *nodes, double *val);
void fill_matrix_H_Sokolov (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                            useful *helper, for_mu *mum,
                            QMatrix_L *A, Vector *b, int time_step);
void fill_matrix_V_Sokolov (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                            useful *helper, for_mu *mum,
                            QMatrix_L *A, Vector *b, int time_step);

#endif // FILL_MATRIX_SOKOLOV_H
