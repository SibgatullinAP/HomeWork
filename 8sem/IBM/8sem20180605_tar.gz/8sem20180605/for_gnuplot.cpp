#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include "for_gnuplot.h"
#include "params.h"
#include "nodes.h"

#define LEN 256

#define FNAME_COM "commands.txt"
#define FNAME_G "g.txt"
#define FNAME_U1 "u1.txt"
#define FNAME_U2 "u2.txt"

void my_sleep (double c)
{
  double t0, t = 0;
  t0 = clock ();
  while (t < c)
    {
      t = (clock () - t0) / CLOCKS_PER_SEC;
    }
}

bool is_need_print (double t)
{
 // return true;

  return (fabs (t - 0) < 1e-8 ||
          fabs (t - 0.5) < 1e-8 ||
          fabs (t - 1) < 1e-8 ||
          fabs (t - 2) < 1e-8 ||
          fabs (t - 3) < 1e-8 ||
          fabs (t - 4) < 1e-8 ||
          fabs (t - 5) < 1e-8 ||
          fabs (t - 6) < 1e-8 ||
          fabs (t - 7) < 1e-8 ||
          fabs (t - 8) < 1e-8 ||
          fabs (t - 9) < 1e-8 ||
          fabs (t - 10) < 1e-8 ||
          fabs (t - 20) < 1e-8 ||
          fabs (t - 30) < 1e-8 ||
          fabs (t - 40) < 1e-8 ||
          fabs (t - 50) < 1e-8 ||
          fabs (t - 60) < 1e-8 ||
          fabs (t - 70) < 1e-8 ||
          fabs (t - 80) < 1e-8 ||
          fabs (t - 90) < 1e-8 ||
          fabs (t - 100) < 1e-8 ||
          fabs (t - 120) < 1e-8 ||
          fabs (t - 150) < 1e-8 ||
          fabs (t - 170) < 1e-8 ||
          fabs (t - 200) < 1e-8 ||
          fabs (t - 250) < 1e-8 ||
          fabs (t - 300) < 1e-8);

  return (fabs (t - 0) < 1e-8 ||
          fabs (t - 0.01) < 1e-8 ||
          fabs (t - 2e-1) < 1e-8 ||
          fabs (t - 4e-1) < 1e-8 ||
          fabs (t - 6e-1) < 1e-8 ||
          fabs (t - 8e-1) < 1e-8 ||
          fabs (t - 1) < 1e-8);
}

void run_gnuplot ()
{
  const char *filename_com = FNAME_COM;
  char path_dest [LEN];

  sprintf (path_dest, "\"gnuplot\" %s%c\"", filename_com,'\0');

  int res = system (path_dest);
  (void) res;

  my_sleep (1e-3);
}

#include "print_values.cpp"

void fill_files_with_values (P_she *p_s, P_nodes *nodes)
{
  FILE *fp_g;
  FILE *fp_u1;
  FILE *fp_u2;
  const char *filename_g = FNAME_G;
  const char *filename_u1 = FNAME_U1;
  const char *filename_u2 = FNAME_U2;

  int dim = p_s->Dim;

  fp_g = fopen (filename_g, "w");
  fp_u1 = fopen (filename_u1, "w");
  fp_u2 = fopen (filename_u2, "w");

  print_values_X_order_exp (p_s, nodes, dim, nodes->G, fp_g);
  //print_values_exp (dim, nodes->G, nodes, fp_g);
  //print_values (dim, nodes->V1, nodes, fp_u1);
  //print_values (dim, nodes->V2, nodes, fp_u2);
  print_values_vectors (dim, p_s, nodes, fp_u1);

  fclose (fp_g);
  fclose (fp_u1);
  fclose (fp_u2);
}

void fill_command_file (const char *val_name, P_she *p_s, int time_step,
                        const char *val_path)
{
  const char *filename_com = FNAME_COM;
  double t = time_step * p_s->tau;

  FILE *f_com;
  f_com = fopen (filename_com, "w");

  fprintf (f_com, "set terminal png size 1024, 768\n");
  fprintf (f_com, "set output '%s/%d.png'\n", val_name, time_step);
  fprintf (f_com, "set xlabel \"t = %.4f\" font \"Times-Roman,30\"\n", t);
  fprintf (f_com, "set xrange [0:3*pi]; set yrange [0:2*pi]\n");
  fprintf (f_com, "%s\n", val_path);

  fclose (f_com);
}

void print_paint_pm3d_command (char *path, const char *fname)
{
  const char *palette = "set palette rgbformulae 36,35,34 negative";
  const char *cbrange = "set cbrange [1:3]";
  const char *map = "set pm3d map";
  sprintf (path, "%s; %s; %s; splot '%s' with pm3d%c",
           palette, cbrange, map, fname, '\0');
  //sprintf (path, "%s; %s; splot '%s' with pm3d%c",
  //         palette, map, fname, '\0');
}

void print_paint_vectors_command (char *path, const char *fname)
{
  sprintf (path, "plot '%s' using 1:2:3:4 with vectors filled head lw 3%c",
           fname, '\0');
}

void print_paint_command (char *path, const char *fname)
{
  sprintf (path, "splot '%s'%c", fname, '\0');
}

void run_gnuplot (P_she *p_s, P_nodes *nodes, int time_step)
{
  double t = time_step * p_s->tau;

  if (!is_need_print (t))
    return;

  fill_files_with_values (p_s, nodes);
  char path_g [LEN];
  char path_u1 [LEN];
  //char path_u2 [LEN];
  print_paint_pm3d_command (path_g, FNAME_G);
  print_paint_vectors_command (path_u1, FNAME_U1);
  //print_paint_command (path_u2, FNAME_U2);

  // GNUPLOT
  fill_command_file ("g",  p_s, time_step, path_g);
  run_gnuplot ();
  fill_command_file ("u1", p_s, time_step, path_u1);
  run_gnuplot ();
  //fill_command_file ("u2", p_s, time_step, path_u2);
  //run_gnuplot ();

}

void clean_png (const char *path)
{
  char path_dest [LEN];

  sprintf (path_dest, "rm -rf %s\\/*.png%c\"", path,'\0');

  int res = system (path_dest);
  (void) res;

  my_sleep (1e-2);
}
