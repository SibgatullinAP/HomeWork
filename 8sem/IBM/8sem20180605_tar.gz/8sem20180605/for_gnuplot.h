#ifndef FOR_GNUPLOT_H
#define FOR_GNUPLOT_H

class P_she;
class P_nodes;

void clean_png (const char *path);

bool is_need_print (double t);
void run_gnuplot ();
void fill_files_with_values (P_she *p_s, P_nodes *nodes);
void fill_command_file (const char *val_name, P_she *p_s, int time_step,
                        const char *val_path);
void run_gnuplot (P_she *p_s, P_nodes *nodes, int time_step);


#endif // FOR_GNUPLOT_H
