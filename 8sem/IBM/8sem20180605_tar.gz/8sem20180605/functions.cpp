#include <stdio.h>
#include <math.h>
#include "functions.h"
#include "settings.h"

extern bool is_known_func;
extern double omega_u;

double u1 (double t, double x, double y)
{
  if (!is_known_func)
    {
      if (fabs (x) < 1e-16)
        return omega_u;
        //return OMEGA_U;
      return 0;
    }

  double res = sin (x) * sin (y) * exp (t);
  return res;
}

double u2 (double t, double x, double y)
{
  if (!is_known_func)
    {
      return 0;
    }

  double res = sin (x) * sin (y) * exp (-t);
  return res;
}

double rho (double t, double x, double y)
{
  if (!is_Sokolov)
    printf ("Do not use rho (t, x, y)!\n");

  double res = exp (g (t, x, y));
  return res;
}

double g (double t, double x, double y)
{
  if (!is_known_func)
    {
      return log (rho_gamma);
    }

  double res = cos (x) * sin (y) + t;
      //= (cos (2 * x) + 3./2.) * (sin (2 * y) + 3./2.);
  //res = log (res);
  //res += t;
  return res;
}

///////////////////////////////////////////////////////////////////////////////

double dg_dt (double , double , double )
{
  return 1;
}

double dg_dx (double , double x, double y)
{
  double res = - sin (x) * sin (y);
      // = - 2 * sin (2 * x);
  //res /= (cos (2 * x) + 3./2.) * (sin (2 * y) + 3./2.);
  return res;
}

double dg_dy (double , double x, double y)
{
  double res = cos (x) * cos (y);
      //= 2 * cos (2 * y);
  //res /= (cos (2 * x) + 3./2.) * (sin (2 * y) + 3./2.);
  return res;
}

double du1_dt (double t, double x, double y)
{
  return u1 (t, x, y);
}

double du1_dx (double t, double x, double y)
{
  if (!is_known_func)
    {
      if (fabs (3 * M_PI - x) < 1e-16)
        return 0;
      printf ("Func: ERR du1_dx\n");
      return 0;
    }

  double res = cos (x) * sin (y) * exp (t);
  return res;
}

double du1_dy (double t, double x, double y)
{
  double res = sin (x) * cos (y) * exp (t);
  return res;
}

double ddu1_dxdx (double t, double x, double y)
{
  return - u1 (t, x, y);
}

double ddu1_dydy (double t, double x, double y)
{
  return - u1 (t, x, y);
}

double ddu1_dxdy (double t, double x, double y)
{
  return cos (x) * cos (y) * exp (t);
}

double du1u1_dx (double t, double x, double y)
{
  return 2 * u1 (t, x, y) * du1_dx (t, x, y);
}

double du2_dt (double t, double x, double y)
{
  return - u2 (t, x, y);
}

double du2_dx (double t, double x, double y)
{
  double res = cos (x) * sin (y) * exp (-t);
  return res;
}

double du2_dy (double t, double x, double y)
{
  double res = sin (x) * cos (y) * exp (-t);
  return res;
}

double ddu2_dxdx (double t, double x, double y)
{
  return - u2 (t, x, y);
}

double ddu2_dydy (double t, double x, double y)
{
  return - u2 (t, x, y);
}

double ddu2_dxdy (double t, double x, double y)
{
  return cos (x) * cos (y) * exp (-t);
}

double du2u2_dy (double t, double x, double y)
{
  return 2 * u2 (t, x, y) * du2_dy (t, x, y);
}

double du1g_dx (double t, double x, double y)
{
  return u1 (t, x, y) * dg_dx (t, x, y) + du1_dx (t, x, y) * g (t, x, y);
}

double du2g_dy (double t, double x, double y)
{
  return u2 (t, x, y) * dg_dy (t, x, y) + du2_dy (t, x, y) * g (t, x, y);
}

double du1u2_dx (double t, double x, double y)
{
  return u1 (t, x, y) * du2_dx (t, x, y) + du1_dx (t, x, y) * u2 (t, x, y);
}

double du1u2_dy (double t, double x, double y)
{
  return u1 (t, x, y) * du2_dy (t, x, y) + du1_dy (t, x, y) * u2 (t, x, y);
}

///////////////////////////////////////////////////////////////////////////////

double Func_0 (double t, double x, double y)
{
  if (!is_known_func)
    return 0;

  double tmp = 2 - g (t, x, y);
  double res =
    + dg_dt (t, x, y)
    + 0.5 * (
      + u1 (t, x, y) * dg_dx (t, x, y)
      + du1g_dx (t, x, y)
      + tmp * du1_dx (t, x, y))
    + 0.5 * (
      + u2 (t, x, y) * dg_dy (t, x, y)
      + du2g_dy (t, x, y)
      + tmp * du2_dy (t, x, y));

  return res;
}

double Func_1 (double t, double x, double y, double p_rho, double mu)
{
  if (!is_known_func)
    return 0;

  double res =
    + du1_dt (t, x, y)
    + (1. / 3.) * (u1 (t, x, y) * du1_dx (t, x, y)
                   + du1u1_dx (t, x, y))
    + (1. / 2.) * (u2 (t, x, y) * du1_dy (t, x, y)
                   + du1u2_dy (t, x, y)
                   - u1 (t, x, y) * du2_dy (t, x, y))
    + p_rho * dg_dx (t, x, y)
    - (mu / exp (g (t, x, y))) * ((4. / 3.) * ddu1_dxdx (t, x, y)
                                  + ddu1_dydy (t, x, y)
                                   + (1. / 3.) * (ddu2_dxdy (t, x, y)));

  return res;
}

double Func_2 (double t, double x, double y, double p_rho, double mu)
{
  if (!is_known_func)
    return 0;

  double res =
      + du2_dt (t, x, y)
      + (1. / 3.) * (u2 (t, x, y) * du2_dy (t, x, y)
                     + du2u2_dy (t, x ,y))
      + (1. / 2.) * (u1 (t, x, y) * du2_dx (t, x, y)
                     + du1u2_dx (t, x, y)
                     - u2 (t, x, y) * du1_dx (t, x, y))
      + p_rho * dg_dy (t, x, y)
      - (mu / exp (g (t, x, y))) * ((4. / 3.) * ddu2_dydy (t, x, y)
                                         + ddu2_dxdx (t, x, y)
                                         + (1. / 3.) * (ddu1_dxdy (t, x, y)));

  return res;
}

double Func_1_S (double t, double x, double y, double (*p_rho)(double), double mu)
{
  if (!is_known_func)
    return 0;

  double res =
    + du1_dt (t, x, y)
    + (1. / 3.) * (u1 (t, x, y) * du1_dx (t, x, y)
                   + du1u1_dx (t, x, y))
    + (1. / 2.) * (u2 (t, x, y) * du1_dy (t, x, y)
                   + du1u2_dy (t, x, y)
                   - u1 (t, x, y) * du2_dy (t, x, y))
    + p_rho (rho (t, x, y)) * dg_dx (t, x, y)
    - (mu / exp (g (t, x, y))) * ((4. / 3.) * ddu1_dxdx (t, x, y)
                                  + ddu1_dydy (t, x, y)
                                   + (1. / 3.) * (ddu2_dxdy (t, x, y)));

  return res;
}

double Func_2_S (double t, double x, double y, double (*p_rho)(double), double mu)
{
  if (!is_known_func)
    return 0;

  double res =
      + du2_dt (t, x, y)
      + (1. / 3.) * (u2 (t, x, y) * du2_dy (t, x, y)
                     + du2u2_dy (t, x ,y))
      + (1. / 2.) * (u1 (t, x, y) * du2_dx (t, x, y)
                     + du1u2_dx (t, x, y)
                     - u2 (t, x, y) * du1_dx (t, x, y))
      + p_rho (rho (t, x, y)) * dg_dy (t, x, y)
      - (mu / exp (g (t, x, y))) * ((4. / 3.) * ddu2_dydy (t, x, y)
                                         + ddu2_dxdx (t, x, y)
                                         + (1. / 3.) * (ddu1_dxdy (t, x, y)));

  return res;
}

