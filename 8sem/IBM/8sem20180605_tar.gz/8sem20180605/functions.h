#ifndef FUNCTIONS_H
#define FUNCTIONS_H

double u1 (double t, double x, double y);
double u2 (double t, double x, double y);
double rho (double t, double x, double y);
double g (double t, double x, double y);

///////////////////////////////////////////////////////////////////////////////

double dg_dt (double , double , double );
double du1_dt (double t, double x, double y);
double du2_dt (double t, double x, double y);
double dg_dx (double , double x, double y);
double dg_dy (double , double x, double y);
double du1_dx (double t, double x, double y);
double du1_dy (double t, double x, double y);
double du2_dx (double t, double x, double y);
double du2_dy (double t, double x, double y);
double ddu1_dxdx (double t, double x, double y);
double ddu1_dydy (double t, double x, double y);
double ddu2_dxdx (double t, double x, double y);
double ddu2_dydy (double t, double x, double y);
double ddu1_dxdy (double t, double x, double y);
double ddu2_dxdy (double t, double x, double y);
double du1u1_dx (double t, double x, double y);
double du2u2_dy (double t, double x, double y);
double du1g_dx (double t, double x, double y);
double du2g_dy (double t, double x, double y);
double du1u2_dx (double t, double x, double y);
double du1u2_dy (double t, double x, double y);

///////////////////////////////////////////////////////////////////////////////

double Func_0 (double t, double x, double y);
double Func_1 (double t, double x, double y, double p_rho, double mu);
double Func_2 (double t, double x, double y, double p_rho, double mu);

double Func_1_S (double t, double x, double y, double (*p_rho)(double), double mu);
double Func_2_S (double t, double x, double y, double (*p_rho)(double), double mu);



#endif // FUNCTIONS_H
