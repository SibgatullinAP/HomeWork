#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "nodes.h"
#include "params.h"
#include "run_test.h"
#include "laspack/errhandl.h"
#include "settings.h"
#include "for_gnuplot.h"

extern int test_count;
extern bool is_known_func;
extern bool need_paint;
extern double omega_u;

int main (int argc, char *argv[])
{
  int n = NN, m1 = MM_X, m2 = MM_Y;
  double p_rho = P_RHO, mu = MU;
  double segm_t = SEGM_T;
  int is_L = 0;

  init_settings ();

  if (argc != 6 && argc != 8 && argc != 11)
    {
      printf ("Usage: %s p_rho mu omega_u segm_t [n m] L_OR_NOT [TEST_COUNT KNOWN_OR_NOT PAINT]\n", argv[0]);
      return 1;
    }
  p_rho = atof (argv[1]);
  mu = atof (argv[2]);
  set_omega_u (atof (argv[3]));
  segm_t = atof (argv[4]);
  is_L = (argc == 6) ? atoi (argv[5]) : atoi (argv[7]);
  if (mu < 0.001 || mu > 0.1 || p_rho <= 0 || segm_t < 1)
    {
      printf ("Error: p_rho, mu, segm_t\n");
      return 1;
    }
  if (argc > 6)
    {
      if ((n = atoi (argv[5])) == 0 || (m1 = m2 = atoi (argv[6])) == 0)
      {
        printf ("Error: n m\n");
        return 1;
      }
    }
  if (argc == 11)
    {
      init_settings (atoi (argv[8]), atoi (argv[9]), atoi (argv[10]));
    }

  print_settings ();

  if (need_paint)
    {
      clean_png ("g");
      clean_png ("u1");
      clean_png ("u2");
    }

  P_gas p_g;
  param_gas (&p_g, p_rho, mu, segm_t);
  P_she p_s;
  param_she_step (&p_g, &p_s, test_count, n, m1, m2);

  int max_dim = get_max_dim (n, m1, m2);
  P_nodes p_nodes;
  create_nodes (&p_nodes, max_dim);

  run_test (&p_g, &p_s, &p_nodes, n, m1, m2, is_L);
  if (LASResult ())
    {
      const char *fl = "LASPACK_ERR.txt";
      printf ("Look %s\n", fl);
      FILE *fp_err;
      fp_err = fopen (fl, "w");
      WriteLASErrDescr (fp_err);
      fclose (fp_err);
    }

  clear_nodes (&p_nodes);
  return 0;
}
