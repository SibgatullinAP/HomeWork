#include <stdio.h>
#include <math.h>
#include "my_arrays.h"

#define EPS 1e-16

// destin = A u
void mult_msr_matrix_vector (
  const double *A, const int *I, // sparse matrix
  unsigned int n,                // order of system
  const double *x,               // (n) u
  double *destin                 // result
  )
{
  unsigned int i, j, l, m;
  double s;

  for (i = 0; i < n; i++)
    {
      s = A[i] * x[i];
      l = I[i + 1] - I[i]; // кол-во внедиаг эл-ов в строке
      m = I[i];
      for (j = 0; j < l; j++)
        {
          s += A[m + j] * x[I[m + j]];
        }
      destin[i] = s;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Jacobi (D / omega)
int apply_preconditioner_msr_matrix (double *A, const int *I, int n, double omega)
{
  double a;
  int i, j, m, l;

  for (i = 0; i < n; i++)
    {
      a = A[i];
      if (fabs (a) < EPS)
        {
          printf ("Fatal error: preconditioning failed.   a[%d] = 0\n", i);
          return -1;
        }
      a /= omega;

      l = I[i + 1] - I[i]; // кол-во внедиаг эл-ов в строке
      m = I[i];

      for (j = 0; j < l; j++)
        {
          A[m + j] /= a;
        }

      A[i] = omega;
    }

  return 0;
}

////////////////////////////////////////////////////////////////////////////////
// Jacobi (D / omega)
int apply_preconditioner_msr_vector (const double *A, const int *, int n, double *b, double omega, double *res)
{
  double a;
  int i;

  for (i = 0; i < n; i++)
    {
      a = A[i];
      if (fabs (a) < EPS)
        {
          printf ("Fatal error: preconditioning failed.   a[%d] = 0\n", i);
          return -1;
        }
      a /= omega;

      res[i] = b[i] / a;
    }

  return 0;
}

////////////////////////////////////////////////////////////////////////////////
void copy_array (int n, const double *src, double *dst)
{
  int i, m;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  for (i = 0; i < m; i++)
    dst[i] = src[i];

  // Unrolled loop
  for (i = m; i < n; i += 8)
    {
      dst[i] = src[i];
      dst[i + 1] = src[i + 1];
      dst[i + 2] = src[i + 2];
      dst[i + 3] = src[i + 3];
      dst[i + 4] = src[i + 4];
      dst[i + 5] = src[i + 5];
      dst[i + 6] = src[i + 6];
      dst[i + 7] = src[i + 7];
    }
}

////////////////////////////////////////////////////////////////////////////////
double e2_norm_array (int n, const double *a)
{
  return sqrt (e2_scalar_product (n, a));
}

////////////////////////////////////////////////////////////////////////////////
double e2_scalar_product (int n, const double *a)
{
  int i, m;
  double res = 0.;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  // Rest of loop
  for (i = 0; i < m; i++)
    res += a[i] * a[i];

  // Unrolled loop
  for (i = m; i < n; i += 8)
    res += a[i] * a[i] + a[i + 1] * a[i + 1]
      + a[i + 2] * a[i + 2] + a[i + 3] * a[i + 3]
      + a[i + 4] * a[i + 4] + a[i + 5] * a[i + 5]
      + a[i + 6] * a[i + 6] + a[i + 7] * a[i + 7];

  return res;
}

////////////////////////////////////////////////////////////////////////////////
double e2_scalar_product_array (int n, const double *a, const double *b)
{
  int i, m;
  double res = 0.;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  // Rest of loop
  for (i = 0; i < m; i++)
    res += a[i] * b[i];

  // Unrolled loop
  for (i = m; i < n; i += 8)
    res += a[i] * b[i] + a[i + 1] * b[i + 1]
      + a[i + 2] * b[i + 2] + a[i + 3] * b[i + 3]
      + a[i + 4] * b[i + 4] + a[i + 5] * b[i + 5]
      + a[i + 6] * b[i + 6] + a[i + 7] * b[i + 7];

  return res;
}

////////////////////////////////////////////////////////////////////////////////
// Subtract arrays: dst = src - dst
void sub_arrays (int n, const double *src, double *dst)
{
  int i, m;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  // Rest of loop
  for (i = 0; i < m; i++)
    dst[i] = src[i] - dst[i];

  // Unrolled loop
  for (i = m; i < n; i += 8)
    {
      dst[i] = src[i] - dst[i];
      dst[i + 1] = src[i + 1] - dst[i + 1];
      dst[i + 2] = src[i + 2] - dst[i + 2];
      dst[i + 3] = src[i + 3] - dst[i + 3];
      dst[i + 4] = src[i + 4] - dst[i + 4];
      dst[i + 5] = src[i + 5] - dst[i + 5];
      dst[i + 6] = src[i + 6] - dst[i + 6];
      dst[i + 7] = src[i + 7] - dst[i + 7];
    }
}

////////////////////////////////////////////////////////////////////////////////
// Summarize arrays: dst = src + dst
void sum_arrays (int n, const double *src, double *dst)
{
  int i, m;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  // Rest of loop
  for (i = 0; i < m; i++)
    dst[i] = src[i] + dst[i];

  // Unrolled loop
  for (i = m; i < n; i += 8)
    {
      dst[i] = src[i] + dst[i];
      dst[i + 1] = src[i + 1] + dst[i + 1];
      dst[i + 2] = src[i + 2] + dst[i + 2];
      dst[i + 3] = src[i + 3] + dst[i + 3];
      dst[i + 4] = src[i + 4] + dst[i + 4];
      dst[i + 5] = src[i + 5] + dst[i + 5];
      dst[i + 6] = src[i + 6] + dst[i + 6];
      dst[i + 7] = src[i + 7] + dst[i + 7];
    }
}

////////////////////////////////////////////////////////////////////////////////
// Summarize arrays: dst = src1 + src2
void sum_arrays2 (int n, const double *src1, const double *src2, double *dst)
{
  int i, m;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  // Rest of loop
  for (i = 0; i < m; i++)
    dst[i] = src1[i] + src2[i];

  // Unrolled loop
  for (i = m; i < n; i += 8)
    {
      dst[i] = src1[i] + src2[i];
      dst[i + 1] = src1[i + 1] + src2[i + 1];
      dst[i + 2] = src1[i + 2] + src2[i + 2];
      dst[i + 3] = src1[i + 3] + src2[i + 3];
      dst[i + 4] = src1[i + 4] + src2[i + 4];
      dst[i + 5] = src1[i + 5] + src2[i + 5];
      dst[i + 6] = src1[i + 6] + src2[i + 6];
      dst[i + 7] = src1[i + 7] + src2[i + 7];
    }
}

////////////////////////////////////////////////////////////////////////////////
// Multiply array a
void multiply_array (int n, double *a, double mult)
{
  int i, m;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  for (i = 0; i < m; i++)
    a[i] *= mult;

  // Unrolled loop
  for (i = m; i < n; i += 8)
    {
      a[i    ] *= mult;
      a[i + 1] *= mult;
      a[i + 2] *= mult;
      a[i + 3] *= mult;
      a[i + 4] *= mult;
      a[i + 5] *= mult;
      a[i + 6] *= mult;
      a[i + 7] *= mult;
    }
}

////////////////////////////////////////////////////////////////////////////////
// Make array linear combination: RES = X + alpha Y
void linear_combination_1 (int n, const double *x, const double *y,
                           double alpha, double *res)
{
  int i, m;

  // Clean-up loop so remaining vector length is a multiple of 8.
  m = n & 7;
  // Rest of loop
  for (i = 0; i < m; i++)
    res[i] = x[i] + alpha * y[i];

  // Unrolled loop
  for (i = m; i < n; i += 8)
    {
      res[i] = x[i] + alpha * y[i];
      res[i + 1] = x[i + 1] + alpha * y[i + 1];
      res[i + 2] = x[i + 2] + alpha * y[i + 2];
      res[i + 3] = x[i + 3] + alpha * y[i + 3];
      res[i + 4] = x[i + 4] + alpha * y[i + 4];
      res[i + 5] = x[i + 5] + alpha * y[i + 5];
      res[i + 6] = x[i + 6] + alpha * y[i + 6];
      res[i + 7] = x[i + 7] + alpha * y[i + 7];
    }
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void print_vector (int n, double *x)
{
  printf ("START vector\n");
  for (int i = 0; i < n; i++)
    {
      printf ("%f\n", x[i]);
    }
  printf ("END vector\n");
}

void print_msr_matrix (double *A, int *I, int size)
{
  printf ("MSR:\n");
  int i, j, k, nz;
  for (i = 0; i < size; i++)
    {
      nz = I[i + 1] - I[i];
      for (j = 0; j < size; j++)
        {
          if (i == j)
            printf ("%.2f ", A[i]);
          else
            {
              for (k = 0; k < nz; k++)
                {
                  if (I[I[i] + k] == j)
                    break;
                }
              if (k == nz)
                printf ("%.2f ", 0.);
              else
                printf ("%.2f ", A[I[i] + k]);
            }
        }
      printf ("\n");
    }
}

void print_msr_matrix_1 (double *A, int *I, int size)
{
  printf ("MSR:\n");
  int i, j, k, nz;
  for (i = 0; i < size; i++)
    {
      nz = I[i + 1] - I[i];
      for (j = 0; j < size; j++)
        {
          double el = 0;
          if (i == j)
            el = A[i];
          else
            {
              for (k = 0; k < nz; k++)
                {
                  if (I[I[i] + k] == j)
                    break;
                }

              if (k != nz)
                el = A[I[i] + k];
            }

          if (fabs (el) > 1e-16)
            printf ("%d %d) %f \n", i, j, el);
        }
      printf ("\n");
    }
}

void print_msr_as_vectors (double *A, int *I, int n)
{
  printf ("MSR_as_vector:\n");
  printf ("A  \n");
  for (int i = 0; i < n; i++)
    {
      printf ("%.3f ", A[i]);
    }
  printf ("\nI  \n");
  for (int i = 0; i < n; i++)
    {
      printf ("%.3d ", I[i]);
    }
  printf ("\n");
}

