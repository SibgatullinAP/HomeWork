#ifndef MY_ARRAYS_H
#define MY_ARRAYS_H

void mult_msr_matrix_vector (
  const double *A, const int *I, // sparse matrix
  unsigned int n,                // order of system
  const double *x,               // (n) u
  double *destin                 // result
  );

// Jacobi
int apply_preconditioner_msr_matrix (double *A, const int *I, int n, double omega);
int apply_preconditioner_msr_vector (const double *A, const int *I, int n, double *b, double omega, double *res);

void copy_array (int n, const double *src, double *dst);
double e2_norm_array (int n, const double *a);
double e2_scalar_product (int n, const double *a);
double e2_scalar_product_array (int n, const double *a, const double *b);
// Subtract arrays: dst = src - dst
void sub_arrays (int n, const double *src, double *dst);
// dst = src + dst
void sum_arrays (int n, const double *src, double *dst);
// dst = src1 + src2
void sum_arrays2 (int n, const double *src1, const double *src2, double *dst);
// a = mult * a
void multiply_array (int n, double *a, double mult);


// Make array linear combination: RES = X + alpha Y
void linear_combination_1 (int n, const double *x, const double *y,
                           double alpha, double *res);

void print_vector (int n, double *x);
void print_msr_matrix (double *A, int *I, int size);
void print_msr_matrix_1 (double *A, int *I, int size);
void print_msr_as_vectors (double *A, int *I, int n);

#endif // MY_ARRAYS_H
