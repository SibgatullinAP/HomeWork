#include <stdio.h>
#include "nodes.h"
#include "params.h"
#include "settings.h"

#define eps 1e-8

void create_nodes (P_nodes *nodes, int max_size)
{
  nodes->max_size = max_size;
  nodes->G = new double [max_size];
  nodes->V1 = new double [max_size];
  nodes->V2 = new double [max_size];
  nodes->st = new int [max_size];
  nodes->X = new double [max_size];
  nodes->Y = new double [max_size];
  nodes->M0L = new int [max_size];
  nodes->M0R = new int [max_size];

  if (is_Sokolov)
    {
      nodes->m_to_half = new int [max_size];
      nodes->half_to_m = new int [max_size];
      nodes->half_st = new int [max_size];
      nodes->H_half_old = new double [max_size];
    }
  else
    {
      nodes->m_to_half = 0;
      nodes->half_to_m = 0;
      nodes->half_st = 0;
      nodes->H_half_old = 0;
    }
}

void clear_nodes (P_nodes *nodes)
{
  delete [] nodes->G;
  delete [] nodes->V1;
  delete [] nodes->V2;
  delete [] nodes->st;
  delete [] nodes->X;
  delete [] nodes->Y;
  delete [] nodes->M0L;
  delete [] nodes->M0R;

  if (is_Sokolov)
    {
      delete [] nodes->m_to_half;
      delete [] nodes->half_to_m;
      delete [] nodes->half_st;
      delete [] nodes->H_half_old;
    }
}

// ///////////////////////////////////////////////////

// Y i--------i
// 2 |   __   |
// 1 |__|--|__|
//   0  1  2  3  X


void fill_states (P_she *p_s, P_nodes *nodes)
{
  int *st = nodes->st;

  int M_x = p_s->M_x;
  int M_y = p_s->M_y;
  int Dim = p_s->Dim;
  int x_count = M_x + 1;

  // inner
  // Dim <= nodes->max_size
  for (int i = 0; i < Dim; i++)
    {
      st[i] = 0;
    }

  //  __  __
  for (int i = 1; i < x_count * 2; i++)
    {
      // ____
      st[i] = 3;
    }

  int top = M_y * x_count * 2;
  int step = x_count * 2;
  int k;
  // |  |  |  |
  for (k = x_count * 2; k < top; k += step)
    {
      // |---
      st[k] = 1;
      st[k + M_x + 1] = 10;
      // ---|
      st[k + M_x] = 9;
      st[k + step - 1] = 2;
    }

  // .  __  .
  // |---
  st[k] = 1;

  k += M_x;
  top = k + M_x;
  for (int i = k + 1; i < top; i++)
    {
      // ____
      st[i] = 3;
    }

  // ---|
  k = top + M_x;
  st[k] = 2;


  // |        |
  top = Dim - 1 - 3 * M_x;
  step = 3 * M_x + 1;
  for (k++; k < top; k += step)
    {
      // |---
      st[k] = 1;
      // ---|
      st[k + step - 1] = 2;
    }

  // .________.
  for (; k < Dim; k++)
    {
      st[k] = 4;
    }

  // L
  st[0] = 5;
  st[x_count] = 12;
  // _|
  st[M_x] = 11;
  st[x_count + M_x] = 6;
  // г
  st[Dim - 1 - 3 * M_x] = 7;
  // 7
  st[Dim - 1] = 8;


  // |-
  k = M_y * 2 * x_count + M_x;
  st[k] = 0;
  // -|
  st[k + M_x] = 0;
}


void fill_coordinates (P_gas *p_g, P_she *p_s, P_nodes *nodes)
{
  double *X = nodes->X;
  double *Y = nodes->Y;

  double curr_x = 0, curr_y = 0;
  double h_x = p_s->h_x;
  double h_y = p_s->h_y;
  int Dim = p_s->Dim;
  double Y_top = p_g->Segm_Y; // 1 out 2
  double X_bottom = p_g->Segm_X; // 1 out 3
  double X_top = X_bottom * 2;

  int y_count = 2 * p_s->M_y + 1;
  int x_count = 3 * p_s->M_x + 1;
  int i, j, num = 0;
  for (i = 0; i < y_count; i++, curr_y += h_y)
    {
      curr_x = 0;
      for (j = 0; j < x_count; j++, curr_x += h_x)
        {
          if (   curr_x - eps > X_bottom && curr_x + eps < X_top
              && curr_y + eps < Y_top)
            continue;

          X[num] = curr_x;
          Y[num] = curr_y;
          num++;
        }
    }

  if (Dim != num)
    {
      printf ("ERROR: fill_coordinates: dim = %d, num = %d\n", Dim, num);
    }
}


void fill_neighbors (P_she *p_s, P_nodes *nodes)
{
  int *M0L = nodes->M0L;  // (x, y - h_y)
  int *M0R = nodes->M0R;  // (x, y + h_y)

  int Dim = p_s->Dim;

  int M_x = p_s->M_x, M_y = p_s->M_y;
  int x_count = M_x + 1;
  int dif = 3 * M_x + 1;
  int i, top, right_neighbor;

  top = M_y * 2 * x_count - x_count;
  for (i = 0; i < top; i++)
    {
      right_neighbor = i + 2 * x_count;
      M0R[i] = right_neighbor;
      M0L[right_neighbor] = i;
    }
  top = Dim - dif;
  for (; i < top; i++)
    {
      right_neighbor = i + dif;
      M0R[i] = right_neighbor;
      M0L[right_neighbor] = i;
    }

  top = x_count * 2;
  for (i = 0; i < top; i++)
    {
      M0L[i] = -1;
    }

  i = M_y * 2 * x_count + M_x;
  top = i + M_x;
  for (i++; i < top; i++)
    {
      M0L[i] = -1;
    }

  for (i = Dim - dif; i < Dim; i++)
    {
      M0R[i] = -1;
    }
}

int get_half_state (int i_main, P_nodes *nodes)
{
  int *st = nodes->st;
  int state = st[i_main];

  if (   state == 4 || state == 7 || state == 8
      || state == 9 || state == 11
      || state == 2 || state == 6)
    return -1;

  if (state == 1)
    {
      if (st[nodes->M0R[i_main]] == 1)
        return 1;
      return 7;
    }
  if (state == 5)
    return 12;
  if (state == 3)
    {
      int st_R0 = st[i_main + 1];
      if (st_R0 == 3 || st_R0 == 0)
        return 3;
      return 6;
    }
  if (state == 10)
    return 10;
  if (state == 12)
    return 12;
  if (state == 0)
    {
      int st_R0 = st[i_main + 1];
      if (st_R0 == 0)
        {
          if (st[nodes->M0R[i_main]] == 0)
            return 0;
          else // == 4
            return 4;
        }
      else if (st_R0 == 2)
        {
          if (st[nodes->M0R[i_main + 1]] == 2)
            return 2;
          return 8;
        }
      else if (st_R0 == 9)
        return 2;
      else if (st_R0 == 3)
        return 3;
    }

  return -1;
}

void fill_half_m_relation (P_she *p_s, P_nodes *nodes)
{
  if (!is_Sokolov)
    return;

  int *st = nodes->st;
  int *half_st = nodes->half_st;
  int *half_to_m = nodes->half_to_m;
  int *m_to_half = nodes->m_to_half;

  int Dim = p_s->Dim;
  int count = 0;
  for (int i = 0; i < Dim; i++)
    {
      int state = st[i];
      if (   state == 4 || state == 7 || state == 8
          || state == 9 || state == 11
          || state == 2 || state == 6)
        {
          m_to_half[i] = -1;
          continue;
        }

      m_to_half[i] = count;
      half_to_m[count] = i;
      half_st[count] = get_half_state (i, nodes);
      count++;
    }
  nodes->half_Dim = count;
}

/////////////////////////////////////////////////////////////////////


void print_area_numbers (P_she *p_s, P_nodes *nodes)
{
  print_area_type (p_s, nodes, 1);
}

void print_area_states (P_she *p_s, P_nodes *nodes)
{
  print_area_type (p_s, nodes, 2);
}

void print_area_R_neighbors (P_she *p_s, P_nodes *nodes)
{
  print_area_type (p_s, nodes, 3);
}

void print_area_L_neighbors (P_she *p_s, P_nodes *nodes)
{
  print_area_type (p_s, nodes, 4);
}

void print_area_X (P_she *p_s, P_nodes *nodes)
{
  print_area_type (p_s, nodes, 5);
}

void print_area_Y (P_she *p_s, P_nodes *nodes)
{
  print_area_type (p_s, nodes, 6);
}

// 0 - spaces
// 1 - numbers
// 2 - states
// 3 - R_neighbor
// 4 - L_neighbor
// 5 - X
// 6 - Y
void printer_number (P_nodes *nodes, int type, int i)
{
  switch (type)
    {
    case 0: printf ("    "); break;
    case 1: printf ("%3d ", i); break;
    case 2: printf ("%3d ", nodes->st[i]); break;
    case 3: printf ("%3d ", nodes->M0R[i]); break;
    case 4: printf ("%3d ", nodes->M0L[i]); break;
    case 5: printf ("%3f ", nodes->X[i]); break;
    case 6: printf ("%3f ", nodes->Y[i]); break;
    case 7: printf ("%3d ", nodes->m_to_half[i]); break;
    case 8:
      {
        int num = nodes->get_half_by_m (i);
        printf ("%3d ", num == -1 ? num : nodes->half_st[num]);
        break;
      }
    default: printf ("CHECK PRINT ERROR\n");
    }
}

void print_area_type (P_she *p_s, P_nodes *nodes, int type)
{
  int M_x = p_s->M_x;
  int M_y = p_s->M_y;
  int Dim = p_s->Dim;

  int i, top, bottom, step;
  int bottom_bottom;

  step = 3 * M_x + 1;
  top = Dim;
  bottom = Dim - step;
  bottom_bottom = M_y * 2 * (M_x + 1);
  for (; bottom >= bottom_bottom; bottom -= step, top -= step)
    {
      for (i = bottom; i < top; i++)
        {
          printer_number (nodes, type, i);
        }
      printf ("\n");
    }

  step = 2 * (M_x + 1);
  top = bottom_bottom;
  bottom = bottom_bottom - step;
  int half_top = bottom + M_x + 1;
  for (; bottom >= 0; bottom -= step, top -= step, half_top -= step)
    {
      for (i = bottom; i < half_top; i++)
        {
          printer_number (nodes, type, i);
        }

      int space_count = p_s->M_x - 1;
      for (int j = 0; j < space_count; j++)
        {
          printer_number (nodes, 0, i);
        }

      for (; i < top; i++)
        {
          printer_number (nodes, type, i);
        }
      printf ("\n");
    }
}

void full_check (P_she *p_s, P_nodes *nodes)
{
  printf ("==== PRINT CHECK START ====\n");
  printf ("NUMBERS\n");
  print_area_numbers (p_s, nodes);
  printf ("STATES\n");
  print_area_states (p_s, nodes);
  printf ("R NEIGHBORS\n");
  print_area_R_neighbors (p_s, nodes);
  printf ("L NEIGHBORS\n");
  print_area_L_neighbors (p_s, nodes);
  printf ("X\n");
  print_area_X (p_s, nodes);
  printf ("Y\n");
  print_area_Y (p_s, nodes);
  if (is_Sokolov)
    {
      printf ("M_to_half\n");
      print_area_type (p_s, nodes, 7);
      printf ("Half_st\n");
      print_area_type (p_s, nodes, 8);
    }
  printf ("==== PRINT CHECK END ====\n");
}


void fill_grid_properties (P_gas *p_g, P_she *p_s, P_nodes *nodes)
{
  fill_states (p_s, nodes);
  fill_coordinates (p_g, p_s, nodes);
  fill_neighbors (p_s, nodes);

  if (is_Sokolov)
    fill_half_m_relation (p_s, nodes);
}

void pr_any (double x)
{
  if (x > 0)
    printf (" %.4f ", x);
  else if (x < 0)
    printf ("%.4f ", x);
  else
    printf (" %.4f ", 0.);
}

void print_in_area (P_she *p_s, double *x)
{
  int M_x = p_s->M_x;
  int M_y = p_s->M_y;
  int Dim = p_s->Dim;

  int i, top, bottom, step;
  int bottom_bottom;

  step = 3 * M_x + 1;
  top = Dim;
  bottom = Dim - step;
  bottom_bottom = M_y * 2 * (M_x + 1);
  for (; bottom >= bottom_bottom; bottom -= step, top -= step)
    {
      for (i = bottom; i < top; i++)
        {
          pr_any (x[i]);
        }
      printf ("\n");
    }

  step = 2 * (M_x + 1);
  top = bottom_bottom;
  bottom = bottom_bottom - step;
  int half_top = bottom + M_x + 1;
  for (; bottom >= 0; bottom -= step, top -= step, half_top -= step)
    {
      for (i = bottom; i < half_top; i++)
        {
          pr_any (x[i]);
        }

      int space_count = p_s->M_x - 1;
      for (int j = 0; j < space_count; j++)
        {
          printf ("        ");
        }

      for (; i < top; i++)
        {
          pr_any (x[i]);
        }
      printf ("\n");
    }
}

void print_in_area_half (P_she *p_s, double *x, P_nodes *nodes)
{
  int M_x = p_s->M_x;
  int M_y = p_s->M_y;
  int Dim = p_s->Dim;

  int i, top, bottom, step;
  int bottom_bottom;

  step = 3 * M_x + 1;
  top = Dim;
  bottom = Dim - step;
  bottom_bottom = M_y * 2 * (M_x + 1);
  for (; bottom >= bottom_bottom; bottom -= step, top -= step)
    {
      for (i = bottom; i < top; i++)
        {
          int j = nodes->get_half_by_m (i);
          if (j != -1)
            pr_any (x[j]);
        }
      printf ("\n");
    }

  step = 2 * (M_x + 1);
  top = bottom_bottom;
  bottom = bottom_bottom - step;
  int half_top = bottom + M_x + 1;
  for (; bottom >= 0; bottom -= step, top -= step, half_top -= step)
    {
      for (i = bottom; i < half_top; i++)
        {
          int j = nodes->get_half_by_m (i);
          if (j != -1)
            pr_any (x[j]);
        }

      int space_count = p_s->M_x - 1;
      for (int j = 0; j < space_count; j++)
        {
          printf ("        ");
        }

      for (; i < top; i++)
        {
          int j = nodes->get_half_by_m (i);
          if (j != -1)
            pr_any (x[j]);
        }
      printf ("\n");
    }
}

void print_in_area_part (P_she *p_s, double *x)
{
  int M_x = p_s->M_x;
  int M_y = p_s->M_y;

  int i, top, bottom, step;

  step = 2 * (M_x + 1);
  top = M_y * 2 * (M_x + 1);
  if (top > 10 * step)
    top = 10 * step;
  bottom = top - step;
  int half_top = bottom + M_x + 1;
  for (; bottom >= 0; bottom -= step, top -= step, half_top -= step)
    {
      half_top = bottom + 10;
      for (i = bottom; i < half_top; i++)
        {
          pr_any (x[i]);
        }
      printf ("\n");
    }
}



int P_nodes::get_half_by_m (int i)
{
  if (i == -1)
    return -1;
  return m_to_half[i];
}

int P_nodes::get_m_by_half (int i)
{
  if (i == -1)
    return -1;
  return half_to_m[i];
}
