#ifndef NODES_H
#define NODES_H

struct P_gas;
struct P_she;

struct P_nodes
{
  int max_size;

  double *G;
  double *V1;
  double *V2;

  int *st;
  double *X;
  double *Y;
  int *M0L;
  int *M0R;

  int *m_to_half;
  int *half_to_m;
  int *half_st;
  double *H_half_old;
  int half_Dim;

  int get_half_by_m (int i);
  int get_m_by_half (int i);
};

void create_nodes (P_nodes *nodes, int max_size);
void clear_nodes (P_nodes *nodes);

// Y   i--------i
// 2pi |   __   |
// 1pi |__|--|__|
//    0 1pi 2pi 3pi  X

void fill_grid_properties (P_gas *p_g, P_she *p_s, P_nodes *nodes);
void fill_states (P_she *p_s, P_nodes *nodes);
void fill_coordinates (P_gas *p_g, P_she *p_s, P_nodes *nodes);
void fill_neighbors (P_she *p_s, P_nodes *nodes);

void fill_half_m_relation (P_she *p_s, P_nodes *nodes);

// check
void print_area_type (P_she *p_s, P_nodes *nodes, int type);
void print_area_numbers (P_she *p_s, P_nodes *nodes);     // 1
void print_area_states (P_she *p_s, P_nodes *nodes);      // 2
void print_area_R_neighbors (P_she *p_s, P_nodes *nodes); // 3
void print_area_L_neighbors (P_she *p_s, P_nodes *nodes); // 4
void print_area_X (P_she *p_s, P_nodes *nodes); // 5
void print_area_Y (P_she *p_s, P_nodes *nodes); // 6
void print_number (P_nodes *nodes, int type, int i); // 0 - spaces
void full_check (P_she *p_s, P_nodes *nodes);

void print_in_area_half (P_she *p_s, double *x, P_nodes *nodes);

void print_in_area (P_she *p_s, double *x);
void print_in_area_part (P_she *p_s, double *x);

#endif // NODES_H
