#include <math.h>
#include "norms.h"
#include "my_arrays.h"
#include "params.h"
#include "nodes.h"


double C_h_norm_2 (double *a, double *b, int n)
{
  double max = fabs (a[0] - b[0]);
  for (int i = 1; i < n; i++)
    {
      double val = fabs (a[i] - b[i]);
      if (val > max)
        max = val;
    }
  return max;
}

bool is_inner (int i, P_nodes *nodes)
{
  int state = nodes->st[i];
  if (state == 0)
    return true;
  return false;
}

double L2_h_norm_2 (double *a, double *b, P_she *p_s, P_nodes *nodes)
{
  double sum = 0;
  int dim = p_s->Dim;
  for (int i = 0; i < dim; i++)
    {
      double el = a[i] - b[i];
      if (is_inner (i, nodes))
        sum += el * el;
      else
        sum += el * el * 0.5;
    }
  sum *= p_s->h_x * p_s->h_x;
  sum = sqrt (sum);
  return sum;
}

bool is_right_wall (int i, P_nodes *nodes)
{
  int state = nodes->st[i];
  if (state == 9 || state == 11 || state == 2 || state == 6 || state == 8)
    return true;
  return false;
}

double v1_h_norm_2 (double *a, double *b, P_she *p_s, P_nodes *nodes)
{
  double sum = 0;
  int dim = p_s->Dim;
  for (int i = 0; i < dim; i++)
    {
      if (!is_right_wall (i, nodes))
        {
          double el_0 = a[i] - b[i];
          double el_1 = a[i + 1] - b[i + 1];
          double pr = el_1 - el_0;
          sum += pr * pr;
        }
    }
  sum = sqrt (sum);
  return sum;
}

double w1_2_h_norm_2 (double *a, double *b, P_she *p_s, P_nodes *nodes)
{
  double L1_h = L2_h_norm_2 (a, b, p_s, nodes);
  double v1_h = v1_h_norm_2 (a, b, p_s, nodes);
  double res = L1_h * L1_h + v1_h * v1_h;
  res = sqrt (res);
  return res;
}

double L2_h_norm_2 (double *a, double *b, int n, double h)
{
  double sum = 0;
  for (int i = 0; i < n; i++)
    {
      double el = a[i] - b[i];
      sum += el * el;
    }
  sum *= h * h;
  sum = sqrt (sum);
  return sum;
}

double v1_h_norm_2 (double *a, double *b, int n, double)
{
  double sum = 0;
  int top = n - 1;
  for (int i = 0; i < top; i++)
    {
      double el_0 = a[i] - b[i];
      double el_1 = a[i + 1] - b[i + 1];
      double pr = el_1 - el_0;
      sum += pr * pr;
    }
  sum = sqrt (sum);
  return sum;
}

double w1_2_h_norm_2 (double *a, double *b, int n, double h)
{
  double L1_h = L2_h_norm_2 (a, b, n, h);
  double v1_h = v1_h_norm_2 (a, b, n, h);
  double res = L1_h * L1_h + v1_h * v1_h;
  res = sqrt (res);
  return res;
}
