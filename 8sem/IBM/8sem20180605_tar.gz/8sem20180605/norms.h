#ifndef NORMS_H
#define NORMS_H

struct P_she;
struct P_nodes;

double C_h_norm_2 (double *a, double *b, int n);
double L2_h_norm_2 (double *a, double *b, P_she *p_s, P_nodes *nodes);
double v1_h_norm_2 (double *a, double *b, P_she *p_s, P_nodes *nodes);
double w1_2_h_norm_2 (double *a, double *b, P_she *p_s, P_nodes *nodes);


double L2_h_norm_2 (double *a, double *b, int n, double h);
double v1_h_norm_2 (double *a, double *b, int n, double h);
double w1_2_h_norm_2 (double *a, double *b, int n, double h);

#endif // NORMS_H
