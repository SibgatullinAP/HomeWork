#include <math.h>
#include "params.h"

/*
#define MM_X 100
#define MM_Y 100 // == MM_X
#define NN 100
#define P_RHO 1
#define MU    0.1
#define SEGM_T 1
*/

// p = rho^gamma
double p_rho_1 (double rho)
{
  return GAMMA * pow (rho, GAMMA - 1);
}

void param_gas (P_gas *p_g, double ini_p_rho = P_RHO, double ini_mu = MU,
                double segm_t = SEGM_T)
{
  p_g->Segm_X = M_PI;
  p_g->Segm_Y = M_PI;
  p_g->Segm_T = segm_t;
  p_g->p_rho = ini_p_rho;
  p_g->p_rho_1 = p_rho_1;
  p_g->mu = ini_mu;
}

// Y i--------i
// 2 |   __   |
// 1 |__|--|__|
//   0  1  2  3  X

int get_t_mult_by_test (int test)
{
  int mult_t = test / 4 + 1;  // 1..4
/*
  if (mult_t == 2)
    return 2;
  else if (mult_t == 3)
    return 4;
  else if (mult_t == 4)
    return 8;
  return 1;
*/
  if (mult_t == 2)
    return 4;
  else if (mult_t == 3)
    return 16;
  else if (mult_t == 4)
    return 64;
  return 1;
}

int get_h_mult_by_test (int test)
{
  int mult_h = test % 4 + 1;  // 1..4
  if (mult_h == 2)
    return 2;
  else if (mult_h == 3)
    return 4;
  else if (mult_h == 4)
    return 8;
  return 1;
}

// test: 0..15
void param_she_step (P_gas *p_g, P_she *p_s, int test,
                     int n = NN, int m1 = MM_X, int m2 = MM_Y)
{
  int mult_t = get_t_mult_by_test (test);
  int mult_h = get_h_mult_by_test (test);

  p_s->N = n * mult_t;
  p_s->M_x = m1 * mult_h;
  p_s->M_y = m2 * mult_h;
  p_s->Dim = p_s->M_y * (p_s->M_x + 1) * 2
           + (p_s->M_y + 1) * (3 * p_s->M_x + 1);
  p_s->h_x = p_g->Segm_X / p_s->M_x;
  p_s->h_y = p_g->Segm_Y / p_s->M_y;
  p_s->tau = p_g->Segm_T / p_s->N;
}


/////////////////////////////////////////////////////////////////////
double get_tau (P_gas *p_g, int test, int n = NN)
{
  int mult_t = get_t_mult_by_test (test);
  int N = n * mult_t;
  return p_g->Segm_T / N;
}

double get_h (P_gas *p_g, int test, int m1 = MM_X)
{
  int mult_h = get_h_mult_by_test (test);
  int M_x = m1 * mult_h;
  return p_g->Segm_X / M_x;
}


/////////////////////////////////////////////////////////////////////
int get_max_dim (int , int m1, int m2)
{
  int M_x = m1 * 16;
  int M_y = m2 * 16;
  return M_y * (M_x + 1) * 2
      + (M_y + 1) * (3 * M_x + 1);
}
