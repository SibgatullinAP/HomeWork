#ifndef PARAMS_H
#define PARAMS_H

#define MM_X 100
#define MM_Y 100
#define NN 100

#define P_RHO 1
#define MU    0.1
#define GAMMA 1.4

#define SEGM_T 1

// Y i--------i
// 2 |   __   |
// 1 |__|--|__|
//   0  1  2  3  X
struct P_gas
{
  double Segm_T;
  double Segm_X;
  double Segm_Y;
  double p_rho;
  double (*p_rho_1)(double);
  double mu;
};

// M_(?) for 1 segment
struct P_she
{
  int M_x;
  int M_y;
  int N;
  int Dim;
  double h_x;
  double h_y;
  double tau;
};

void param_gas (P_gas *p_g, double ini_p_rho, double ini_mu, double segm_t);
void param_she_step (P_gas *p_g, P_she *p_s, int test, int n, int m1, int m2);

/////////////////////////////////////////////////////////////////////
double get_tau (P_gas *p_g, int test, int n);
double get_h (P_gas *p_g, int test, int m1);

/////////////////////////////////////////////////////////////////////
int get_max_dim (int n, int m1, int m2);

#endif // PARAMS_H
