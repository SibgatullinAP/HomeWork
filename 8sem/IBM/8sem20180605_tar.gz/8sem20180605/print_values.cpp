#include <stdio.h>
#include <math.h>
#include "print_values.h"
#include "params.h"
#include "nodes.h"

void print_values_X_order (P_she *p_s, P_nodes *nodes, int n, double *val, FILE *fp)
{
  double *X = nodes->X;
  double *Y = nodes->Y;

  double x = 0;
  double h = p_s->h_x;
  int M = p_s->M_x;
  int print_count = 0;

  int top = 3 * M + 1;
  for (int i = 0; i < top; i++, x += h)
    {
      for (int j = n - 1; j >= 0; j--)
        {
          if (fabs (x - X[j]) > 1e-12)
            continue;

          fprintf (fp, "%e %e %e\n", X[j], Y[j], val[j]);
          print_count++;
        }
      fprintf (fp, "\n");
    }

  if (print_count != n)
    printf ("Error in print_values_X_order\n");
}

void print_values_X_order_exp (P_she *p_s, P_nodes *nodes, int n, double *val, FILE *fp)
{
  double *X = nodes->X;
  double *Y = nodes->Y;

  double x = 0;
  double h = p_s->h_x;
  int M = p_s->M_x;
  int print_count = 0;

  int top = 3 * M + 1;
  for (int i = 0; i < top; i++, x += h)
    {
      for (int j = n - 1; j >= 0; j--)
        {
          if (fabs (x - X[j]) > 1e-12)
            continue;

          fprintf (fp, "%e %e %e\n", X[j], Y[j], exp (val[j]));
          print_count++;
        }
      fprintf (fp, "\n");
    }

  if (print_count != n)
    printf ("Error in print_values_X_order\n");
}

void print_values (int n, double *val, P_nodes *nodes, FILE *fp)
{
  double *X = nodes->X;
  double *Y = nodes->Y;
  //fprintf (fp, "X Y Z\n");
  for (int i = 0; i < n; i++)
    {
      fprintf (fp, "%e %e %e\n", X[i], Y[i], val[i]);
    }
}

void print_values_exp (int n, double *val, P_nodes *nodes, FILE *fp)
{
  double *X = nodes->X;
  double *Y = nodes->Y;
  //fprintf (fp, "X Y Z\n");
  for (int i = 0; i < n; i++)
    {
      fprintf (fp, "%e %e %e\n", X[i], Y[i], exp (val[i]));
    }
}

double get_x_delta (double x, double y, double h)
{
  double d = sqrt (x * x + y * y);
  if (d < 1e-16)
    return 0;
  d /= h;
  return x / d;
}

double get_y_delta (double x, double y, double h)
{
  double d = sqrt (x * x + y * y);
  if (d < 1e-16)
    return 0;
  d /= h;
  return y / d;
}

void print_values_vectors (int n, P_she *p_s, P_nodes *nodes, FILE *fp)
{
  double *X = nodes->X;
  double *Y = nodes->Y;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  double h = p_s->h_x;

  // x y x_delta y_delta
  for (int i = 0; i < n; i++)
    {
      double v1 = V1[i], v2 = V2[i];
      fprintf (fp, "%e %e %e %e\n", X[i], Y[i],
               get_x_delta (v1, v2, h), get_y_delta (v1, v2, h));
    }
}
