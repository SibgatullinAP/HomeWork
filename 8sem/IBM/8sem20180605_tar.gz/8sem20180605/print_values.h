#ifndef PRINT_VALUES_H
#define PRINT_VALUES_H
#include <stdio.h>

class P_she;
class P_nodes;

void print_values_X_order (P_she *p_s, P_nodes *nodes, int n, double *val, FILE *fp);
void print_values_X_order_exp (P_she *p_s, P_nodes *nodes, int n, double *val, FILE *fp);
void print_values (int n, double *val, P_nodes *nodes, FILE *fp);
void print_values_exp (int n, double *val, P_nodes *nodes, FILE *fp);
void print_values_vectors (int n, P_she *p_s, P_nodes *nodes, FILE *fp);

#endif // PRINT_VALUES_H
