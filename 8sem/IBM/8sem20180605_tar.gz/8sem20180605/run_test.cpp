#include <time.h>
#include <stdio.h>
#include "run_test.h"
#include "my_arrays.h"
#include "params.h"
#include "scheme.h"
#include "functions.h"
#include "nodes.h"
#include "norms.h"
#include "settings.h"
#include "scheme_Sokolov.h"

extern int test_count;
extern bool is_known_func;
extern bool need_paint;

void run_test (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               int n = NN, int m1 = MM_X, int m2 = MM_Y, int is_L = 0)
{
  if (is_L)
    printf ("--> Laspack\n");

  double t = 0;
  int it_test;

  double *nc_g = new double [test_count];
  double *nl2_g = new double [test_count];
  double *n1_2_g = new double [test_count];
  double *nc_v1 = new double [test_count];
  double *nl2_v1 = new double [test_count];
  double *n1_2_v1 = new double [test_count];
  double *nc_v2 = new double [test_count];
  double *nl2_v2 = new double [test_count];
  double *n1_2_v2 = new double [test_count];
  double *time = new double [test_count];

  int max_size = nodes->max_size;
  double *g_val = new double [max_size];
  double *u1_val = new double [max_size];
  double *u2_val = new double [max_size];

  double *WORKSPACE = new double [30 * max_size];

  for (it_test = 0; it_test < test_count; it_test++)
    {
      param_she_step (p_g, p_s, it_test, n, m1, m2);
      fill_grid_properties (p_g, p_s, nodes);
      //full_check (p_s, nodes);

      t = clock ();
      if (is_L/* && !is_Sokolov*/)
        {
          if (scheme_L (p_g, p_s, nodes, u1_val, u2_val))
          //if (scheme_L (p_g, p_s, nodes))
            {
              printf ("ERROR in scheme! test %d\n", it_test);
              continue;
            }
        }
      /*else if (!is_Sokolov)
        {
          if (scheme (p_g, p_s, nodes, WORKSPACE))
            {
              printf ("ERROR in scheme! test %d\n", it_test);
              continue;
            }
        }*/
      else
        {
          if (scheme_Sokolov (p_g, p_s, nodes))
            {
              printf ("ERROR in scheme! test %d\n", it_test);
              continue;
            }
        }
      t = (clock () - t) / CLOCKS_PER_SEC;


      // check
      //print_3_in_area (p_s, nodes, "check in run_test: results");
      // //////////////////////////


      if (is_known_func)
        {
          fill_true_values (p_g, p_s, nodes, g_val, u1_val, u2_val, is_L);
          //
          //print_3_in_area (p_s, g_val, u1_val, u2_val, "\n\nTRUE\n");
          // //////////////////////////

               //
               //printf ("\n\nTRUE\n");
               //print_in_area (p_s, g_val);
               //print_in_area (p_s, u1_val);
               //print_in_area (p_s, u2_val);
               // //////////////////////////

          // norms
          int dim = p_s->Dim;
          nc_v1[it_test]  = C_h_norm_2  (nodes->V1, u1_val, dim);
          nl2_v1[it_test] = L2_h_norm_2 (nodes->V1, u1_val, p_s, nodes);
          n1_2_v1[it_test] = w1_2_h_norm_2 (nodes->V1, u1_val, p_s, nodes);
          nc_v2[it_test]  = C_h_norm_2  (nodes->V2, u2_val, dim);
          nl2_v2[it_test] = L2_h_norm_2 (nodes->V2, u2_val, p_s, nodes);
          n1_2_v2[it_test] = w1_2_h_norm_2 (nodes->V2, u2_val, p_s, nodes);
          time[it_test]   = t;
          if (is_Sokolov)
            {
              int half_dim = nodes->half_Dim;
              double h = p_s->h_x;
              nc_g[it_test]   = C_h_norm_2  (nodes->G, g_val, half_dim);
              nl2_g[it_test]  = L2_h_norm_2 (nodes->G, g_val, half_dim, h);
              n1_2_g[it_test] = w1_2_h_norm_2 (nodes->G, g_val, half_dim, h);
            }
          else
            {
              nc_g[it_test]   = C_h_norm_2  (nodes->G, g_val, dim);
              nl2_g[it_test]  = L2_h_norm_2 (nodes->G, g_val, p_s, nodes);
              n1_2_g[it_test] = w1_2_h_norm_2 (nodes->G, g_val, p_s, nodes);
            }

          printf ("RESULTS: %d %d\n%f %f %f\n%f %f %f\n %f %f %f\n %f\n",
                  p_s->N, p_s->M_x,
                  nc_g[it_test], nl2_g[it_test], n1_2_g[it_test],
                  nc_v1[it_test], nl2_v1[it_test], n1_2_v1[it_test],
                  nc_v2[it_test], nl2_v2[it_test], n1_2_v2[it_test],
                  time[it_test]);
        }

      printf ("Elapsed (%d) = %.2f\n", it_test, t);

    }

 if (is_known_func && test_count == 16)
   {
     // print results in file
     const char *name = "tables.txt";
     FILE *fp = fopen (name, "w");
     print_table (p_g, test_count, n, m1, nc_g, fp,   "$|G - g|_C$");
     print_table (p_g, test_count, n, m1, nl2_g, fp,  "$|G - g|_{L2}$");
     print_table (p_g, test_count, n, m1, n1_2_g, fp, "$|G - g|^1_2$");
     print_table (p_g, test_count, n, m1, nc_v1, fp,  "$|V1 - u1|_C$");
     print_table (p_g, test_count, n, m1, nl2_v1, fp, "$|V1 - u1|_{L2}$");
     print_table (p_g, test_count, n, m1, n1_2_v1, fp, "$|V1 - u1|^1_2$");
     print_table (p_g, test_count, n, m1, nc_v2, fp,  "$|V2 - u2|_C$");
     print_table (p_g, test_count, n, m1, nl2_v2, fp, "$|V2 - u2|_{L2}$");
     print_table (p_g, test_count, n, m1, n1_2_v2, fp, "$|V2 - u2|^1_2$");
     print_time  (p_g, test_count, n, m1, time, fp,   "time");

     fclose (fp);
   }

  delete [] nc_g;
  delete [] nl2_g;
  delete [] n1_2_g;
  delete [] nc_v1;
  delete [] nl2_v1;
  delete [] n1_2_v1;
  delete [] nc_v2;
  delete [] nl2_v2;
  delete [] n1_2_v2;
  delete [] time;

  delete [] g_val;
  delete [] u1_val;
  delete [] u2_val;
  delete [] WORKSPACE;
}

/////////////////////////////////////////////////////////////////////
void fill_true_values (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                       double *g_val, double *u1_val, double *u2_val, bool is_L)
{
  fill_u1 (p_g, p_s, nodes, u1_val);
  fill_u2 (p_g, p_s, nodes, u2_val);

  if (/*is_Sokolov*/ !is_L)
    fill_g_half (p_g, p_s, nodes, g_val);
  else
    fill_g (p_g, p_s, nodes, g_val);
}

void fill_g (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *g_val)
{
  int dim = p_s->Dim;
  double t = p_g->Segm_T;
  double *X = nodes->X;
  double *Y = nodes->Y;
  for (int i = 0; i < dim; i++)
    {
      g_val[i] = g (t, X[i], Y[i]);
    }
}

void fill_g_half (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *g_val)
{
  int half_Dim = nodes->half_Dim;
  double t = p_g->Segm_T;
  double *X = nodes->X;
  double *Y = nodes->Y;
  double h_x = p_s->h_x, h_y = p_s->h_y;
  for (int i = 0; i < half_Dim; i++)
    {
      double x = X[nodes->get_m_by_half (i)] + h_x * 0.5;
      double y = Y[nodes->get_m_by_half (i)] + h_y * 0.5;
      g_val[i] = rho (t, x, y);
    }
}

void fill_u1 (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *u1_val)
{
  int dim = p_s->Dim;
  double t = p_g->Segm_T;
  double *X = nodes->X;
  double *Y = nodes->Y;
  for (int i = 0; i < dim; i++)
    {
      u1_val[i] = u1 (t, X[i], Y[i]);
    }
}

void fill_u2 (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *u2_val)
{
  int dim = p_s->Dim;
  double t = p_g->Segm_T;
  double *X = nodes->X;
  double *Y = nodes->Y;
  for (int i = 0; i < dim; i++)
    {
      u2_val[i] = u2 (t, X[i], Y[i]);
    }
}

#define BEG_TAB "\\begin{tabular}{|c|c|c|c|c|}\n"
#define END_TAB "\\end{tabular}\n\\[9pt]\n"
#define line "\\hline\n"
#define multicol "\\multicolumn{5}{c}"

/////////////////////////////////////////////////////////////////////
void print_table (P_gas *p_g, int n_test, int n, int m, double *x,
                  FILE *fp, const char *norm_name)
{
  double tau, h1, h2, h3, h4;
  h1 = get_h (p_g, 0, m);
  h2 = get_h (p_g, 1, m);
  h3 = get_h (p_g, 2, m);
  h4 = get_h (p_g, 3, m);

  fprintf (fp, "%s", BEG_TAB);
  fprintf (fp, "%s{%s}\\\\%s", multicol, norm_name, line);
  fprintf (fp, "$\\tau$   | h & %f &   %f &   %f &   %f \\\\ \n",
           h1, h2, h3, h4);
  fprintf (fp, "%s", line);
  for (int i = 0; i < n_test; i += 4)
    {
      tau = get_tau (p_g, i, n);
      fprintf (fp, "%f & %.3e & %.3e & %.3e & %.3e \\\\ \n",
               tau, x[i], x[i + 1], x[i + 2], x[i + 3]);
      fprintf (fp, "%s", line);
    }
  fprintf (fp, "%s", END_TAB);
}

void print_time (P_gas *p_g, int n_test, int n, int m, double *x,
                 FILE *fp, const char *norm_name)
{
  double tau, h1, h2, h3, h4;
  h1 = get_h (p_g, 0, m);
  h2 = get_h (p_g, 1, m);
  h3 = get_h (p_g, 2, m);
  h4 = get_h (p_g, 3, m);

  fprintf (fp, "%s", BEG_TAB);
  fprintf (fp, "%s{%s}\\\\%s", multicol, norm_name, line);
  fprintf (fp, "$\\tau$   | h & %f & %f & %f & %f \\\\ \n",
           h1, h2, h3, h4);
  fprintf (fp, "%s", line);
  for (int i = 0; i < n_test; i += 4)
    {
      tau = get_tau (p_g, i, n);
      fprintf (fp, "%f & %.4f & %.4f & %.4f & %.4f \\\\ \n",
               tau, x[i], x[i + 1], x[i + 2], x[i + 3]);
      fprintf (fp, "%s", line);
    }
  fprintf (fp, "%s", END_TAB);
}
