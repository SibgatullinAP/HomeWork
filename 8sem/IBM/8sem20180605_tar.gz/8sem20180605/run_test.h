#ifndef RUN_TEST_H
#define RUN_TEST_H

#include <stdio.h>

struct P_gas;
struct P_she;
struct P_nodes;

void run_test (P_gas *p_g, P_she *p_s, P_nodes *nodes,
               int n, int m1, int m2, int is_L);

/////////////////////////////////////////////////////////////////////
void fill_true_values (P_gas *p_g, P_she *p_s, P_nodes *nodes,
                       double *g_val, double *u1_val, double *u2_val, bool is_L);
void fill_g (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *g_val);
void fill_g_half (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *g_val);
void fill_u1 (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *u1_val);
void fill_u2 (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *u2_val);

/////////////////////////////////////////////////////////////////////
void print_table (P_gas *p_g, int n_test, int n, int m, double *x,
                  FILE *fp, const char *norm_name);
void print_time (P_gas *p_g, int n_test, int n, int m, double *x,
                 FILE *fp, const char *norm_name);


#endif // RUN_TEST_H
