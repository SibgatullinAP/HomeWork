#include <stdio.h>
#include "scheme.h"
#include "params.h"
#include "nodes.h"
#include "useful.h"
#include "cgs.h"
#include "fill_matrix.h"
#include "fill_matrix_L.h"
#include "start_data.h"
#include "my_arrays.h"
#include "laspack/qmatrix.h"
#include "laspack/rtc.h"
#include "laspack/errhandl.h"
#include "L.h"
#include "for_gnuplot.h"
#include "settings.h"
#include "norms.h"

#define solve_eps 1e-8
extern int test_count;
extern bool is_known_func;
extern bool need_paint;

void print_3_vector (P_she *p_s, P_nodes *nodes, const char *s)
{
  int size = p_s->Dim;
  printf ("NOW: 3V: %s\n", s);
  print_vector (size, nodes->G);
  print_vector (size, nodes->V1);
  print_vector (size, nodes->V2);
}

void print_3_in_area (P_she *p_s, double *x, double *y, double *z, const char *s)
{
  printf ("NOW: 3V (x, y, z): %s\n", s);
  printf ("x:\n");
  print_in_area (p_s, x);
  printf ("y:\n");
  print_in_area (p_s, y);
  printf ("z:\n");
  print_in_area (p_s, z);
}

void print_3_in_area (P_she *p_s, P_nodes *nodes, const char *s)
{
  printf ("NOW: 3V: %s\n", s);
  printf ("G:\n");
  print_in_area (p_s, nodes->G);
  printf ("V1:\n");
  print_in_area (p_s, nodes->V1);
  printf ("V2:\n");
  print_in_area (p_s, nodes->V2);
}

void print_3_in_area_part (P_she *p_s, P_nodes *nodes, const char *s)
{
  printf ("NOW: 3V: %s\n", s);
  printf ("G:\n");
  print_in_area_part (p_s, nodes->G);
  printf ("V1:\n");
  print_in_area_part (p_s, nodes->V1);
  printf ("V2:\n");
  print_in_area_part (p_s, nodes->V2);
}

static
void answer_to_nodes (P_she *p_s, P_nodes *nodes, double *d)
{
  int Dim = p_s->Dim;
  double *G = nodes->G;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  for (int i = 0; i < Dim; i++)
    {
      int k = 3 * i;
      G[i] = d[k];
      V1[i] = d[k + 1];
      V2[i] = d[k + 2];
    }
}

int scheme (P_gas *p_g, P_she *p_s, P_nodes *nodes,
            double *WORKSPACE /* 30 max_size */)
{
  int N = p_s->N;
  int time_step;
  useful helper;
  for_mu mu_helper;

  double *A = 0;
  int *I = 0;
  double *rhs, *d, *d_ini, *workspace;
  int n_matrix = 0;
  int size = 3 * p_s->Dim;

  rhs = WORKSPACE;
  d = rhs + size;
  d_ini = rhs + size;
  workspace = d_ini + size;


  helper.init_usewful (p_g, p_s);
  fill_start_data (p_g, p_s, nodes);

  init_d_ini (p_s, nodes, d_ini);
  for (time_step = 0; time_step < N; time_step++)
    {
      mu_helper.init_for_mu (p_g, p_s, nodes);

      assemble_matrix (p_g, p_s, nodes, &n_matrix, &I, &A);
      init_arrays (p_s, rhs, d, workspace);



      fill_matrix (p_g, p_s, nodes, &helper, &mu_helper, A, I, rhs, time_step);
      if (time_step == 0)
        {
      //  print_3_in_area (p_s, nodes, "for start");
      //  print_vector (size, rhs);
      //  print_msr_matrix_1 (A, I, size);
        }
/*
      // check
      print_msr_as_vectors (A, I, n_matrix);
      print_msr_matrix (A, I, size);
      print_vector (size, rhs);
      print_vector (size, d);
      print_vector (size, d_ini);
      // ////////////////////////////////////////
*/

      int iter_count = solve_linear_system_cgs (A, I, size, rhs, d_ini, d, workspace);
      if (iter_count < 0)
        {
          printf ("ERROR! %d\n", iter_count);
          return -1;
        }

      answer_to_nodes (p_s, nodes, d);
      copy_array (size, d, d_ini);

      //if (time_step == 0)
        //print_3_in_area (p_s, nodes, "after 1");

      if (need_paint)
        {
          run_gnuplot (p_s, nodes, time_step);
        }
    }

  delete [] I;
  delete [] A;

  return 0;
}

void init_arrays (P_she *p_s, double *rhs, double *d,
                  double *workspace)
{
  int size = 3 * p_s->Dim;

  for (int i = 0; i < size; i++)
    {
      rhs[i] = d[i] = 0;
    }

  int top = size * 7;
  for (int i = 0; i < top; i += 2)
    {
      workspace[i] = 0;
    }
}

void init_d_ini (P_she *p_s, P_nodes *nodes, double *d_ini)
{
  int size = 3 * p_s->Dim;
  double *G = nodes->G;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  for (int i = 0; i < size; i += 3)
    {
      d_ini[i] = G[i];
      d_ini[i + 1] = V1[i];
      d_ini[i + 2] = V2[i];
    }
}

//////////////////////////////////////////////////////////////////////////

static
void answer_to_nodes_L (P_she *p_s, P_nodes *nodes, Vector *d)
{
  int Dim = p_s->Dim;
  double *G = nodes->G;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  for (int i = 0; i < Dim; i++)
    {
      int k = 3 * i + 1;
      G[i] = V_GetCmp (d, k);
      V1[i] = V_GetCmp (d, k + 1);
      V2[i] = V_GetCmp (d, k + 2);
    }
}

static
void init_x (P_she *p_s, P_nodes *nodes, Vector *x)
{
  int size = p_s->Dim;
  double *G = nodes->G;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  for (int i = 0; i < size; i++)
    {
      int k = 3 * i + 1;
      V_SetCmp (x, k, G[i]);
      V_SetCmp (x, k + 1, V1[i]);
      V_SetCmp (x, k + 2, V2[i]);
    }
}

int scheme_L (P_gas *p_g, P_she *p_s, P_nodes *nodes)
{
  int N = p_s->N;
  int size = 3 * p_s->Dim;
  int time_step;
  useful helper;
  for_mu mu_helper;

  QMatrix_L A;
  Vector b, x;

  Q_Constr (&A, "A", size, False, Rowws, Normal, True);
  V_Constr (&b, "b", size, Normal, True);
  V_Constr (&x, "x", size, Normal, True);

  helper.init_usewful (p_g, p_s);
  fill_start_data (p_g, p_s, nodes);

  //print_3_in_area (p_s, nodes, "start_data_L");

  init_x (p_s, nodes, &x);
  for (time_step = 0; time_step < N; time_step++)
    {
      mu_helper.init_for_mu (p_g, p_s, nodes);

      fill_matrix_L (p_g, p_s, nodes, &helper, &mu_helper, &A, &b, time_step);
      if (time_step == 0)
        {
       //   print_3_in_area (p_s, nodes, "for start");
      //    V_Print (&b);
      //  Q_Print (&A);
        }

      SetRTCAccuracy (solve_eps);
      CGSIter (&A, &x, &b, 2000, JacobiPrecond, 1);

      answer_to_nodes_L (p_s, nodes, &x);
      //print_3_in_area (p_s, nodes, "start_data_L+");
      //print_3_in_area_part (p_s, nodes, "start_data_L+");

      //if (time_step == 0)
      //  print_3_in_area (p_s, nodes, "after 1");

      if (need_paint)
        {
          run_gnuplot (p_s, nodes, time_step);
        }
    }

  Q_Destr (&A);
  V_Destr (&b);
  V_Destr (&x);

  return 0;
}


int scheme_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
              double *v1, double *v2)
{
  int N = p_s->N;
  int size = 3 * p_s->Dim;
  int dim = p_s->Dim;
  int time_step;
  useful helper;
  for_mu mu_helper;

  QMatrix_L A;
  Vector b, x;

  Q_Constr (&A, "A", size, False, Rowws, Normal, True);
  V_Constr (&b, "b", size, Normal, True);
  V_Constr (&x, "x", size, Normal, True);

  helper.init_usewful (p_g, p_s);
  fill_start_data (p_g, p_s, nodes);

  //print_3_in_area (p_s, nodes, "start_data_L");

  init_x (p_s, nodes, &x);
  for (time_step = 0; time_step < N; time_step++)
    {
      copy_array (dim, nodes->V1, v1);
      copy_array (dim, nodes->V2, v2);

      mu_helper.init_for_mu (p_g, p_s, nodes);

      fill_matrix_L (p_g, p_s, nodes, &helper, &mu_helper, &A, &b, time_step);
      if (time_step == 0)
        {
       //   print_3_in_area (p_s, nodes, "for start");
      //    V_Print (&b);
      //  Q_Print (&A);
        }

      SetRTCAccuracy (solve_eps);
      CGSIter (&A, &x, &b, 2000, JacobiPrecond, 1);

      answer_to_nodes_L (p_s, nodes, &x);
      //print_3_in_area (p_s, nodes, "start_data_L+");
      //print_3_in_area_part (p_s, nodes, "start_data_L+");

      //if (time_step == 0)
      //  print_3_in_area (p_s, nodes, "after 1");

      if (need_paint)
        {
          run_gnuplot (p_s, nodes, time_step);
        }
/*
 * //
      double r_1 = w1_2_h_norm_2  (nodes->V1, v1, p_s, nodes);
      double r_2 = w1_2_h_norm_2  (nodes->V2, v2, p_s, nodes);
      if (r_1 < 1e-3 && r_2 < 1e-3)
        {
          printf ("OK! t = %f (%d): %e  %e\n", time_step * p_s->tau, time_step, r_1, r_2);
          break;
        }
        */
    }

  Q_Destr (&A);
  V_Destr (&b);
  V_Destr (&x);

  return 0;
}
