#ifndef SCHEME_H
#define SCHEME_H

struct P_gas;
struct P_she;
struct P_nodes;

void print_3_in_area (P_she *p_s, double *x, double *y, double *z, const char *s = "");
void print_3_in_area (P_she *p_s, P_nodes *nodes, const char *s = "");
void print_3_in_area_part (P_she *p_s, P_nodes *nodes, const char *s = "");

void init_arrays (P_she *p_s, double *rhs, double *d,
                  double *workspace);
void init_d_ini (P_she *p_s, P_nodes *nodes, double *d_ini);
int scheme (P_gas *p_g, P_she *p_s, P_nodes *nodes, double *WORKSPACE /* 30 max_size */);

int scheme_L (P_gas *p_g, P_she *p_s, P_nodes *nodes);
int scheme_L (P_gas *p_g, P_she *p_s, P_nodes *nodes,
              double *v1, double *v2);

#endif // SCHEME_H
