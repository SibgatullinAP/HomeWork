#include <stdio.h>
#include "scheme_Sokolov.h"
#include "params.h"
#include "nodes.h"
#include "useful.h"
#include "my_arrays.h"
#include "fill_matrix_Sokolov.h"
#include "start_data.h"
#include "laspack/qmatrix.h"
#include "laspack/rtc.h"
#include "laspack/errhandl.h"
#include "L.h"
#include "for_gnuplot.h"
#include "settings.h"
#include "functions.h"

#define solve_eps 1e-8
extern int test_count;
extern bool is_known_func;
extern bool need_paint;

void print_3_in_areaS (P_she *p_s, double *x, double *y, double *z, const char *s)
{
  printf ("NOW: 3V (x, y, z): %s\n", s);
  printf ("x:\n");
  print_in_area (p_s, x);
  printf ("y:\n");
  print_in_area (p_s, y);
  printf ("z:\n");
  print_in_area (p_s, z);
}

void print_3_in_areaS (P_she *p_s, P_nodes *nodes, const char *s)
{
  printf ("NOW: 3V: %s\n", s);
  printf ("G:\n");
  print_in_area_half (p_s, nodes->G, nodes);
  printf ("V1:\n");
  print_in_area (p_s, nodes->V1);
  printf ("V2:\n");
  print_in_area (p_s, nodes->V2);
}

//////////////////////////////////////////////////////////////////////////
static
void answer_to_H_half (P_she *, P_nodes *nodes, Vector *d_H)
{
  int Dim = nodes->half_Dim;
  double *H_half = nodes->G;
  for (int i = 0; i < Dim; i++)
    {
      H_half[i] = V_GetCmp (d_H , i + 1);
    }
}

static
void answer_to_V (P_she *p_s, P_nodes *nodes, Vector *d_V)
{
  int Dim = p_s->Dim;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  for (int i = 0; i < Dim; i++)
    {
      int k = 2 * i + 1;
      V1[i] = V_GetCmp (d_V, k);
      V2[i] = V_GetCmp (d_V, k + 1);
    }
}

static
void init_x_H (P_she *, P_nodes *nodes, Vector *x)
{
  int half_size = nodes->half_Dim;
  double *H_half = nodes->G;
  for (int i = 0; i < half_size; i++)
    {
      V_SetCmp (x, i + 1, H_half[i]);
    }
}

static
void init_x_V (P_she *p_s, P_nodes *nodes, Vector *x)
{
  int size = p_s->Dim;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  for (int i = 0; i < size; i++)
    {
      int k = 2 * i + 1;
      V_SetCmp (x, k, V1[i]);
      V_SetCmp (x, k + 1, V2[i]);
    }
}

int scheme_Sokolov (P_gas *p_g, P_she *p_s, P_nodes *nodes)
{
  int N = p_s->N;
  int size_H = nodes->half_Dim;
  int size_V = 2 * p_s->Dim;
  int time_step;
  useful helper;
  for_mu mu_helper;

  QMatrix_L A_H;
  QMatrix_L A_V;
  Vector b_H, b_V, x_H, x_V;

  Q_Constr (&A_H, "A_H", size_H, False, Rowws, Normal, True);
  V_Constr (&b_H, "b_H", size_H, Normal, True);
  V_Constr (&x_H, "x_H", size_H, Normal, True);

  Q_Constr (&A_V, "A_V", size_V, False, Rowws, Normal, True);
  V_Constr (&b_V, "b_V", size_V, Normal, True);
  V_Constr (&x_V, "x_V", size_V, Normal, True);

  helper.init_usewful (p_g, p_s);
  fill_start_data_Sokolov (p_g, p_s, nodes);

  //print_3_in_area (p_s, nodes, "start_data_L");

  init_x_H (p_s, nodes, &x_H);
  init_x_V (p_s, nodes, &x_V);
  for (time_step = 0; time_step < N; time_step++)
    {
      copy_array (nodes->half_Dim, nodes->G, nodes->H_half_old);
      mu_helper.init_for_mu (p_g, p_s, nodes);

      fill_matrix_H_Sokolov (p_g, p_s, nodes, &helper, &mu_helper, &A_H, &b_H, time_step + 1);
      SetRTCAccuracy (solve_eps);
      CGSIter (&A_H, &x_H, &b_H, 2000, JacobiPrecond, 1);

      answer_to_H_half (p_s, nodes, &x_H);

      //V_Print (&x_H);
      //print_vector (size_H, nodes->H_half);
      //print_vector (p_s->Dim, nodes->G);
      //print_in_area (p_s, nodes->G);

      //if (time_step == 0)
        //print_3_in_area (p_s, nodes, "after 1");

      fill_matrix_V_Sokolov (p_g, p_s, nodes, &helper, &mu_helper, &A_V, &b_V, time_step);
      //Q_Print_S (&A_V);
      //V_Print (&b_V);
      SetRTCAccuracy (solve_eps);
      CGSIter (&A_V, &x_V, &b_V, 2000, JacobiPrecond, 1);

      //V_Print (&x_V);
      answer_to_V (p_s, nodes, &x_V);

      //if (time_step == 0)
        //print_3_in_areaS (p_s, nodes, "after 1 (S)");

      if (need_paint)
        {
          run_gnuplot (p_s, nodes, time_step);
        }
    }

  Q_Destr (&A_H);
  V_Destr (&b_H);
  V_Destr (&x_H);
  Q_Destr (&A_V);
  V_Destr (&b_V);
  V_Destr (&x_V);

  return 0;
}

