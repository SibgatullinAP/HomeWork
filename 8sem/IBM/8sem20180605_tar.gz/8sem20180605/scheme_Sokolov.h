#ifndef SCHEME_SOKOLOV_H
#define SCHEME_SOKOLOV_H

struct P_gas;
struct P_she;
struct P_nodes;

int scheme_Sokolov (P_gas *p_g, P_she *p_s, P_nodes *nodes);

#endif // SCHEME_SOKOLOV_H
