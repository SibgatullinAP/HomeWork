#include <stdio.h>
#include <math.h>
#include "settings.h"

int test_count;
bool is_known_func;
bool need_paint;
double omega_u;

//#define OMEGA_U_2 0.01

void init_settings (int ini_tc, bool ini_kf, bool ini_np)
{
  test_count = ini_tc;
  is_known_func = ini_kf;
  need_paint = ini_np;

  if (test_count != 1)
    need_paint = false;
}

void set_omega_u (double ini_omega_u)
{
  if (fabs (ini_omega_u - OMEGA_U) < 1e-16)
    omega_u = OMEGA_U;
  else
    omega_u = ini_omega_u;
}

void print_settings ()
{
  const char *paint_str = need_paint ? "true" : "false";
  const char *known_f_str = is_known_func ? "known" : "unknown";
  printf ("Test count: %d\n", test_count);
  printf ("Functions: %s\n", known_f_str);
  printf ("Paint: %s\n", paint_str);
  printf ("Omega_u = : %f\n", omega_u);
}
