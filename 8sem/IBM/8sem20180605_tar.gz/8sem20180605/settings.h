#ifndef SETTINGS_H
#define SETTINGS_H

#define TEST_MAX   1
#define PAINT      false
#define KNOWN_FUNC true
#define OMEGA_U 0.1
#define rho_gamma 1
#define is_Sokolov true

void init_settings (int ini_tc = TEST_MAX,
                    bool ini_kf = KNOWN_FUNC,
                    bool ini_np = PAINT);

void set_omega_u (double ini_omega_u = OMEGA_U);

void print_settings ();

#endif // SETTINGS_H
