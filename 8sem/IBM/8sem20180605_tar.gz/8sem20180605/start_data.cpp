#include "start_data.h"
#include "params.h"
#include "nodes.h"
#include "functions.h"

void fill_start_data (P_gas *, P_she *p_s, P_nodes *nodes)
{
  int Dim = p_s->Dim;
  double *G = nodes->G;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  double *X = nodes->X;
  double *Y = nodes->Y;

  for (int i = 0; i < Dim; i++)
    {
      double x = X[i];
      double y = Y[i];
      G[i] = g (0, x, y);
      V1[i] = u1 (0, x, y);
      V2[i] = u2 (0, x, y);
    }
}

void fill_start_data_Sokolov (P_gas *, P_she *p_s, P_nodes *nodes)
{
  int Dim = p_s->Dim;
  double *V1 = nodes->V1;
  double *V2 = nodes->V2;
  double *X = nodes->X;
  double *Y = nodes->Y;

  for (int i = 0; i < Dim; i++)
    {
      double x = X[i];
      double y = Y[i];
      V1[i] = u1 (0, x, y);
      V2[i] = u2 (0, x, y);
    }

  double h_x = p_s->h_x;
  double h_y = p_s->h_y;
  double *H = nodes->G;
  double *H_half_old = nodes->H_half_old;
  int half_Dim = nodes->half_Dim;
  for (int i = 0; i < half_Dim; i++)
    {
      double x = X[nodes->get_m_by_half (i)] + h_x * 0.5;
      double y = Y[nodes->get_m_by_half (i)] + h_y * 0.5;
      H[i] = H_half_old[i] = rho (0, x, y);
    }
}
