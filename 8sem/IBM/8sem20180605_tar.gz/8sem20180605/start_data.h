#ifndef START_DATA_H
#define START_DATA_H

struct P_gas;
struct P_she;
struct P_nodes;

void fill_start_data (P_gas *p_g, P_she *p_s, P_nodes *nodes);
void fill_start_data_Sokolov (P_gas *, P_she *p_s, P_nodes *nodes);


#endif // START_DATA_H
