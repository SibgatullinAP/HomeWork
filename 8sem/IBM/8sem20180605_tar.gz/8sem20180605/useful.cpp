#include <math.h>
#include "useful.h"
#include "nodes.h"
#include "params.h"


void useful::init_usewful (const P_gas *p_g, const P_she *p_s)
{
  double tau = p_s->tau, h_x = p_s->h_x, h_y = p_s->h_y;
  double tmp;

  thx = tau / h_x;
  thy = tau / h_y;
  thx05 = thx / 2;
  thy05 = thy / 2;
  thx025 = thx / 4;
  thy025 = thy / 4;
  thx2 = 2 * thx;
  thy2 = 2 * thy;
  thx4 = 4 * thx;
  thy4 = 4 * thy;
  thx32 = (3. / 2.) * thx;
  thy32 = (3. / 2.) * thy;
  tau2 = 2 * tau;
  tau4 = 4 * tau;
  tau6 = 6 * tau;
  tmp = tau / (h_x * h_x);
  thxx8 = 8 * tmp;
  thxx6 = 6 * tmp;
  tmp = tau / (h_y * h_y);
  thyy8 = 8 * tmp;
  thyy6 = 6 * tmp;
  thxy = tau / (2 * h_x * h_y);
  tmp = 3 * tau * p_g->p_rho;
  Max = tmp / h_x;
  May = tmp / h_y;
}


void for_mu::init_for_mu (const P_gas *p_g, const P_she *p_s, const P_nodes *nodes)
{
  double tau = p_s->tau, h_x = p_s->h_x, h_y = p_s->h_y;
  double mu = p_g->mu;
  double tmp;

  MUM = max_exp_minus (nodes->G, p_s->Dim);
  MUM *= mu;
  tmp = (tau * MUM) / (h_x * h_x);
  MU8x = 8 * tmp;
  MU6x = 6 * tmp;
  tmp = (tau * MUM) / (h_y * h_y);
  MU8y = 8 * tmp;
  MU6y = 6 * tmp;
  MUv1 = 6 + tau * MUM * (16 / (h_x * h_x) + 12 / (h_y * h_y));
  MUv2 = 6 + tau * MUM * (16 / (h_y * h_y) + 12 / (h_x * h_x));

  MUv1S = tau * mu * (8 / (3 * h_x * h_x) + 2 / (h_y * h_y));
  MUv2S = tau * mu * (8 / (3 * h_y * h_y) + 2 / (h_x * h_x));
  MUxS = (mu * tau) / (h_x * h_x);
  MUyS = (mu * tau) / (h_y * h_y);
  MUxS43 = (4 * MUxS) / 3;
  MUyS43 = (4 * MUyS) / 3;
  MUg = 1.4;
  MUxyS = (mu * tau) / (12 * h_x * h_y);
}


double max_exp_minus (const double *x, int n)
{
  double tmp = exp (-x[0]);
  double max = tmp;

  for (int i = 1; i < n; i++)
    {
      tmp = exp (-x[i]);
      if (tmp > max)
        max = tmp;
    }
  return max;
}
