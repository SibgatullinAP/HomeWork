#ifndef USEFUL_H
#define USEFUL_H

struct P_gas;
struct P_she;
struct P_nodes;

struct useful
{
  double thx, thy;
  double thx05, thy05;
  double thx025, thy025;
  double thx2, thy2;
  double thx4, thy4;
  double thx32, thy32;
  double tau2, tau4, tau6;
  double thxx8, thyy8;
  double thxx6, thyy6;
  double thxy;
  double Max, May;

  void init_usewful (const P_gas *p_g, const P_she *p_s);
};

struct for_mu
{
  double MUM;
  double MU8x;
  double MU8y;
  double MU6x;
  double MU6y;
  double MUv1;
  double MUv2;

  double MUv1S;
  double MUv2S;
  double MUxS;
  double MUyS;
  double MUxS43;
  double MUyS43;
  double MUg;
  double MUxyS;

  void init_for_mu (const P_gas *p_g, const P_she *p_s, const P_nodes *nodes);
};


double max_exp_minus (const double *x, int n);


#endif // USEFUL_H
