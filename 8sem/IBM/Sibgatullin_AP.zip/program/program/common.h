#ifndef COMMON_H
#define COMMON_H

#include<math.h>
#include <optional>
#include <algorithm>
#include <string>
#include <vector>
#include <stdio.h>
#include <math.h>
#include <stdarg.h>

const double NEARZERO = 1.0e-10;

#define MAX_STR_BUFF 100

#endif // COMMON_H
