#ifndef SEQUENCES_H
#define SEQUENCES_H

#include "constants.h"

int rms_deviation (const char *file_name, double *answer); //Root-mean-squared deviation

#endif //SEQUENCES_H
