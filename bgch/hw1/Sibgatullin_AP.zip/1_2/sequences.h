#ifndef SEQUENCES_H
#define SEQUENCES_H

#include "constants.h"

int check (const char *file_name_1, const char *file_name_2); //Root-mean-squared deviation

#endif //SEQUENCES_H
