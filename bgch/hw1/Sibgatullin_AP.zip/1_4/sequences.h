#ifndef SEQUENCES_H
#define SEQUENCES_H

#include "constants.h"

int type_of_sequence (const char *file_name);

#endif //SEQUENCES_H
