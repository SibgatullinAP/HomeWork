#include "constants.h"

int read (const char *file_name, double *arr, int size);
void print (double *arr, int size);
void randomize (double *arr, int array_size);
int greatest_common_devisor(int x, int y);
void shift_to_k (double *arr, int size, int shift);



