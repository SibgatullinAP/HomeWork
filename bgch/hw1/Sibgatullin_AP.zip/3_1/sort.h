#include "constants.h"

int read (const char *file_name, double *arr, int size);
int binary_search (const double *arr, int size, double x);
void print (double *arr, int size);
