#include "constants.h"

int read (const char *file_name, double *arr, int size);
void print (double *arr, int size);
void check (double *arr, int size);
void quick_sort (double *arr, int size);
int array_redbuilding (double *arr, int size, double x);
void swap (double *a, int i, int j);



