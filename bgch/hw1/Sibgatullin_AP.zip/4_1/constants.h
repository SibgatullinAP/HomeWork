#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stddef.h>

#define STRING_BUFF 1024

#endif //CONSTANTS_H
