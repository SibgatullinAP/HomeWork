#ifndef STRING__H
#define STRING__H

#include "constants.h"

int strcspn_ (const char *string_1, const char *string_2);

#endif //STRING__H
