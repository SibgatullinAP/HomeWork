#ifndef TASK
#define TASK

int avg (const char *file_name, double *avg);
int counter (const char *file_name, double avg);

#endif
