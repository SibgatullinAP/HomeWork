#ifndef THREAD_H
#define THREAD_H

void *thread_func (void *);

#endif
